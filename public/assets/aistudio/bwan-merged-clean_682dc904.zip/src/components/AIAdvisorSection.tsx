import React, { useState, useRef, useEffect } from 'react';
import { Send, MessageSquare, RotateCcw, Sparkles } from 'lucide-react';
import { AppLanguage } from './Navbar';

interface ChatMessage {
  id: string;
  role: 'user' | 'model';
  text: string;
  modelUsed?: string;
}

const QUICK_CLUB_QUESTIONS = [
  'Giới thiệu về dự án 18 Nguyên Tố Nhân Cách Gen 6',
  'Lịch các sự kiện sắp tới của CLB Hóa Học BWAN?',
  'CLB có những phân ban nào và cách đăng ký tham gia?',
];

interface AIAdvisorSectionProps {
  lang: AppLanguage;
}

export const AIAdvisorSection: React.FC<AIAdvisorSectionProps> = ({ lang }) => {
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: 'welcome-msg',
      role: 'model',
      text: 'Xin chào! Mình là Trợ lý Đại sứ của **BWAN Club (Gen 6)**. Bạn muốn tìm hiểu về các dự án thực nghiệm, Hệ thống Giải mã 18 Nguyên tố Nhân cách, lịch sự kiện sắp tới hay cách ứng tuyển vào CLB?',
      modelUsed: 'gemini-3.8-flash',
    },
  ]);
  const [input, setInput] = useState('');
  const [mode, setMode] = useState<'fast' | 'general' | 'deep'>('general');
  const [loading, setLoading] = useState(false);
  const [chatError, setChatError] = useState<string | null>(null);
  const threadContainerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (messages.length > 1 && threadContainerRef.current) {
      threadContainerRef.current.scrollTop = threadContainerRef.current.scrollHeight;
    }
  }, [messages]);

  const sendMessage = async (textToSend: string) => {
    const trimmed = textToSend.trim();
    if (!trimmed) {
      setChatError('Vui lòng nhập câu hỏi trước khi gửi.');
      return;
    }

    setChatError(null);
    const userMsg: ChatMessage = {
      id: `user-${Date.now()}`,
      role: 'user',
      text: trimmed,
    };

    const historyPayload = messages.map((m) => ({
      role: m.role,
      text: m.text,
    }));

    setMessages((prev) => [...prev, userMsg]);
    setInput('');
    setLoading(true);

    try {
      const response = await fetch('/api/club/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          message: trimmed,
          history: historyPayload,
          mode,
        }),
      });

      const data = await response.json();
      if (!response.ok) {
        setChatError(data.error || 'Không thể gửi tin nhắn lúc này.');
      } else {
        const botMsg: ChatMessage = {
          id: `model-${Date.now()}`,
          role: 'model',
          text: data.reply,
          modelUsed: data.model,
        };
        setMessages((prev) => [...prev, botMsg]);
      }
    } catch {
      setChatError('Lỗi kết nối tới máy chủ CLB. Vui lòng thử lại.');
    } finally {
      setLoading(false);
    }
  };

  const handleFormSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    sendMessage(input);
  };

  return (
    <section
      id="tro-ly-clb"
      className="py-20 px-4 sm:px-6 lg:px-8 bg-transparent transition-colors"
    >
      <div className="max-w-5xl mx-auto">
        <div className="flex flex-col lg:flex-row lg:items-end justify-between gap-6">
          <div className="max-w-2xl">
            <p className="text-xs font-mono font-semibold text-[#6C63FF] dark:text-[#A39DFF] tracking-wide">
              {lang === 'vi'
                ? '05. KẾT NỐI & TRÒ CHUYỆN CÙNG ĐẠI SỨ CLB'
                : '05. CHAT WITH BWAN CLUB AMBASSADOR'}
            </p>
            <h2 className="mt-2 font-display text-3xl sm:text-4xl font-bold text-[#1F1F2E] dark:text-white tracking-tight text-balance">
              {lang === 'vi'
                ? 'Trợ Lý Câu Lạc Bộ Hóa Học '
                : 'Chemistry Club Assistant '}
              <span className="google-one-chem-gradient-text">BWAN Chatbot</span>
            </h2>
            <p className="mt-2.5 text-sm sm:text-base text-[#4A4A68] dark:text-[#CBD5E1] leading-relaxed">
              {lang === 'vi'
                ? 'Giải đáp trực tiếp mọi thắc mắc về chuỗi dự án, lịch trình sự kiện, thông tin các phân ban và kiến thức Hóa học thú vị.'
                : 'Ask anything about our experimental projects, upcoming events, club divisions, and chemistry topics.'}
            </p>
          </div>

          {/* Model Speed / Depth Selector */}
          <div
            role="group"
            aria-label="Chọn chế độ phản hồi"
            className="flex flex-wrap items-center gap-1.5 p-1.5 bg-white/80 dark:bg-[#191632] border border-[#E5E2DC] dark:border-[#6C63FF]/30 rounded-2xl shrink-0"
          >
            {[
              { id: 'fast', label: 'Nhanh (Flash Lite)' },
              { id: 'general', label: 'Tiêu chuẩn (3.8 Flash)' },
              { id: 'deep', label: 'Chuyên sâu (4 Argon)' },
            ].map((item) => (
              <button
                key={item.id}
                type="button"
                onClick={() => setMode(item.id as typeof mode)}
                className={`px-3.5 py-2 text-xs font-semibold rounded-xl transition-colors cursor-pointer whitespace-nowrap shrink-0 ${
                  mode === item.id
                    ? 'bg-[#6C63FF] text-white shadow-xs'
                    : 'text-[#4A4A68] dark:text-[#CBD5E1] hover:text-[#1F1F2E] dark:hover:text-white'
                }`}
              >
                {item.label}
              </button>
            ))}
          </div>
        </div>

        {/* Multi-Turn Chat Interface Card */}
        <div className="mt-8 bg-white/90 dark:bg-[#16142E]/90 backdrop-blur-md rounded-[32px] border border-[#E5E2DC] dark:border-[#6C63FF]/30 overflow-hidden shadow-sm">
          {/* Top Bar */}
          <div className="px-6 py-4 bg-white dark:bg-[#121026] border-b border-[#E5E2DC] dark:border-[#6C63FF]/25 flex items-center justify-between gap-4">
            <div className="flex items-center gap-3">
              <MessageSquare className="w-5 h-5 text-[#6C63FF] dark:text-[#A39DFF]" />
              <div>
                <h3 className="font-display text-sm sm:text-base font-bold text-[#1F1F2E] dark:text-white">
                  Hộp Thoại Trực Tuyến — BWAN Club
                </h3>
                <p className="text-xs text-[#5F6368] dark:text-[#94A3B8]">
                  Lưu lịch sử hội thoại nhiều lượt · Tương thích mọi thiết bị
                </p>
              </div>
            </div>

            <button
              type="button"
              onClick={() =>
                setMessages([
                  {
                    id: 'welcome-reset',
                    role: 'model',
                    text: 'Hội thoại đã được làm mới! Bạn cần tìm hiểu thêm về dự án hay sự kiện nào của BWAN Club?',
                    modelUsed: 'gemini-3.8-flash',
                  },
                ])
              }
              className="inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded-full bg-[#F1F0FF] dark:bg-[#6C63FF]/25 hover:bg-[#E5E3FF] text-xs font-semibold text-[#6C63FF] dark:text-[#A39DFF] cursor-pointer whitespace-nowrap shrink-0"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span>Làm mới hội thoại</span>
            </button>
          </div>

          {/* Scrollable Message Thread */}
          <div
            ref={threadContainerRef}
            data-testid="club-chat-thread"
            className="p-6 space-y-4 max-h-96 overflow-y-auto"
          >
            {messages.map((msg) => (
              <div
                key={msg.id}
                className={`flex flex-col ${
                  msg.role === 'user' ? 'items-end' : 'items-start'
                }`}
              >
                <div
                  className={`max-w-2xl rounded-2xl px-4 py-3 text-sm leading-relaxed whitespace-pre-line ${
                    msg.role === 'user'
                      ? 'bg-[#6C63FF] text-white font-medium shadow-xs'
                      : 'bg-[#F4F2EE] dark:bg-[#1E1B3D] text-[#1F1F2E] dark:text-white border border-[#E5E2DC] dark:border-[#6C63FF]/25 shadow-2xs'
                  }`}
                >
                  {msg.text}
                </div>
                <span className="mt-1 text-[11px] font-mono text-[#5F6368] dark:text-[#94A3B8]">
                  {msg.role === 'user'
                    ? 'Bạn'
                    : `Đại sứ BWAN · ${msg.modelUsed || 'gemini-3.8-flash'}`}
                </span>
              </div>
            ))}
            {loading && (
              <div className="flex items-center gap-2 text-xs font-mono font-semibold text-[#6C63FF] dark:text-[#A39DFF]">
                <Sparkles className="w-4 h-4 animate-spin" />
                <span>Đại sứ CLB đang soạn phản hồi...</span>
              </div>
            )}
          </div>

          {/* Quick Question Prompts + Input Form */}
          <div className="p-5 bg-white dark:bg-[#121026] border-t border-[#E5E2DC] dark:border-[#6C63FF]/25 space-y-3">
            <div className="flex flex-wrap items-center gap-2">
              {QUICK_CLUB_QUESTIONS.map((q) => (
                <button
                  key={q}
                  type="button"
                  onClick={() => sendMessage(q)}
                  className="text-xs px-3.5 py-1.5 rounded-full bg-[#F1F0FF] dark:bg-[#6C63FF]/20 hover:bg-[#6C63FF] hover:text-white text-[#6C63FF] dark:text-[#A39DFF] font-medium transition-colors cursor-pointer whitespace-nowrap shrink-0"
                >
                  {q}
                </button>
              ))}
            </div>

            {chatError && (
              <p role="alert" className="text-xs text-[#DC2626] dark:text-[#F87171] font-semibold">
                {chatError}
              </p>
            )}

            <form onSubmit={handleFormSubmit} className="flex items-center gap-3">
              <label htmlFor="club-chat-input" className="sr-only">
                Nhập câu hỏi cho Câu lạc bộ Hóa Học
              </label>
              <input
                id="club-chat-input"
                type="text"
                value={input}
                onChange={(e) => setInput(e.target.value)}
                placeholder="Hỏi về dự án 18 Nguyên tố, sự kiện sắp tới hoặc cách tham gia CLB..."
                className="flex-1 px-4 py-3 rounded-full bg-[#F8F9FA] dark:bg-[#0D0C1D] border border-[#DBD8D0] dark:border-[#6C63FF]/35 text-sm text-[#1F1F2E] dark:text-white placeholder-[#9CA3AF] focus:outline-none focus:border-[#6C63FF]"
              />
              <button
                type="submit"
                disabled={loading}
                className="inline-flex items-center gap-2 px-6 py-3 rounded-full google-one-chem-btn text-sm font-semibold disabled:opacity-60 cursor-pointer whitespace-nowrap shrink-0"
              >
                <span>Gửi</span>
                <Send className="w-4 h-4" />
              </button>
            </form>
          </div>
        </div>
      </div>
    </section>
  );
};
