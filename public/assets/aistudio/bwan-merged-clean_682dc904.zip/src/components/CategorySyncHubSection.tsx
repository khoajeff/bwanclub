import React, { useState } from 'react';
import {
  ClubProjectItem,
  ClubEventItem,
  parseAndSyncClubProject,
} from '../utils/chemistryEngine';
import {
  Calendar,
  MapPin,
  Sparkles,
  UploadCloud,
  CheckCircle,
  FolderGit2,
  ArrowUpRight,
} from 'lucide-react';
import { AppLanguage } from './Navbar';

interface CategorySyncHubSectionProps {
  projects: ClubProjectItem[];
  events: ClubEventItem[];
  onAddProject: (newProj: ClubProjectItem) => void;
  onOpenJoinModal: (defaultTopic?: string) => void;
  lang: AppLanguage;
}

const SAMPLE_SYNC_JSON = JSON.stringify(
  {
    title: '05. Triển Lãm Nhiếp Ảnh Vi Tinh Thể Hóa Học (Micro-Crystal Art)',
    category: 'su-kien',
    code: 'BWAN-EVT-05',
    semester: 'Gen 6 · 2026',
    highlightMetric: '30 tác phẩm kính hiển vi phân cực',
    chemicalTheme: 'AgNO₃ + Cu → Tinh thể Bạc nhánh dương xỉ',
    summary:
      'Ghi lại quá trình hình thành mạng tinh thể kim loại và muối vô cơ dưới kính hiển vi quang học độ phóng đại 400x do chính thành viên CLB thực hiện.',
  },
  null,
  2
);

export const CategorySyncHubSection: React.FC<CategorySyncHubSectionProps> = ({
  projects,
  events,
  onAddProject,
  onOpenJoinModal,
  lang,
}) => {
  const [activeFilter, setActiveFilter] = useState<
    'all' | 'du-an' | 'su-kien' | 'nghien-cuu' | 'ung-dung'
  >('all');
  const [customTitle, setCustomTitle] = useState('');
  const [customCategory, setCustomCategory] = useState<
    'du-an' | 'su-kien' | 'nghien-cuu' | 'ung-dung'
  >('du-an');
  const [payloadText, setPayloadText] = useState('');
  const [syncError, setSyncError] = useState<string | null>(null);
  const [syncSuccess, setSyncSuccess] = useState<string | null>(null);

  const filteredProjects =
    activeFilter === 'all'
      ? projects
      : projects.filter((p) => p.category === activeFilter);

  const handleSyncSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setSyncError(null);
    setSyncSuccess(null);

    const validation = parseAndSyncClubProject(
      payloadText,
      customTitle,
      customCategory
    );
    if (!validation.valid || !validation.item) {
      setSyncError(validation.error || 'Dữ liệu danh mục không hợp lệ.');
      return;
    }

    onAddProject(validation.item);
    setCustomTitle('');
    setPayloadText('');
    setSyncSuccess(
      `Đã đồng bộ danh mục "${validation.item.title}" vào hệ thống CLB!`
    );
  };

  return (
    <>
      {/* SECTION 02: PROJECTS SHOWCASE */}
      <section
        id="du-an"
        className="google-one-chem-section-wash py-20 px-4 sm:px-6 lg:px-8 border-b border-[#EFECE6] dark:border-[#6C63FF]/20 transition-colors"
      >
        <div className="max-w-7xl mx-auto">
          {/* Header & Filter Bar */}
          <div className="flex flex-col lg:flex-row lg:items-end justify-between gap-6">
            <div className="max-w-3xl">
              <p className="text-xs font-mono font-semibold text-[#6C63FF] dark:text-[#A39DFF] tracking-wide">
                {lang === 'vi'
                  ? '02. DỰ ÁN & CÔNG TRÌNH TIÊU BIỂU CỦA CLB'
                  : '02. FEATURED CLUB PROJECTS & RESEARCH'}
              </p>
              <h2 className="mt-2 font-display text-3xl sm:text-4xl font-bold text-[#1F1F2E] dark:text-white tracking-tight text-balance">
                {lang === 'vi' ? 'Dự Án Thực Nghiệm & ' : 'Experimental Projects & '}
                <span className="google-one-chem-gradient-text">
                  {lang === 'vi' ? 'Sản Phẩm Sáng Tạo BWAN' : 'BWAN Innovations'}
                </span>
              </h2>
              <p className="mt-3 text-base text-[#4A4A68] dark:text-[#CBD5E1] leading-relaxed">
                {lang === 'vi'
                  ? 'Tổng hợp các dự án nghiên cứu, sản phẩm công nghệ Hóa Học và triển lãm thực nghiệm do chính học sinh trong Câu lạc bộ khởi xướng và vận hành.'
                  : 'Explore student-led chemistry research, interactive web applications, and experimental showcases built by BWAN Club members.'}
              </p>
            </div>

            {/* Interactive Category Filter Buttons */}
            <div
              role="group"
              aria-label="Lọc dự án theo danh mục"
              className="flex flex-wrap items-center gap-1.5 p-1.5 bg-[#EAE7E0] dark:bg-[#191632] rounded-2xl shrink-0"
            >
              {[
                { id: 'all', label: lang === 'vi' ? 'Tất cả' : 'All' },
                { id: 'ung-dung', label: lang === 'vi' ? 'Ứng dụng số' : 'Digital App' },
                { id: 'du-an', label: lang === 'vi' ? 'Thực nghiệm' : 'Lab Project' },
                { id: 'nghien-cuu', label: lang === 'vi' ? 'Nghiên cứu' : 'Research' },
                { id: 'su-kien', label: lang === 'vi' ? 'Triển lãm' : 'Showcase' },
              ].map((tab) => (
                <button
                  key={tab.id}
                  type="button"
                  onClick={() =>
                    setActiveFilter(tab.id as typeof activeFilter)
                  }
                  className={`px-4 py-2 text-xs font-semibold rounded-xl transition-colors cursor-pointer whitespace-nowrap shrink-0 ${
                    activeFilter === tab.id
                      ? 'bg-[#6C63FF] text-white shadow-xs'
                      : 'text-[#4A4A68] dark:text-[#CBD5E1] hover:text-[#1F1F2E] dark:hover:text-white hover:bg-white/60 dark:hover:bg-[#231F44]'
                  }`}
                >
                  {tab.label}
                </button>
              ))}
            </div>
          </div>

          {/* Featured Flagship Project Spotlight */}
          <div className="mt-10 bg-white dark:bg-[#16142E] rounded-[32px] p-6 sm:p-8 lg:p-10 border border-[#E5E2DC] dark:border-[#6C63FF]/30 shadow-sm grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
            <div className="lg:col-span-6 space-y-4">
              <div className="flex flex-wrap items-center gap-2 text-xs font-mono font-semibold">
                <span className="text-[#6C63FF] dark:text-[#A39DFF]">
                  {lang === 'vi' ? 'DỰ ÁN TRỌNG ĐIỂM GEN 6' : 'GEN 6 FLAGSHIP PROJECT'}
                </span>
                <span aria-hidden="true" className="text-[#9CA3AF]">·</span>
                <span className="text-[#0284C7] dark:text-[#38BDF8]">
                  {lang === 'vi' ? '18 NGUYÊN TỐ NHÂN CÁCH' : '18 PERSONALITY ELEMENTS'}
                </span>
                <span aria-hidden="true" className="text-[#9CA3AF]">·</span>
                <span className="text-[#0D9488] dark:text-[#34D399]">● ĐANG MỞ CỔNG</span>
              </div>

              <h3 className="font-display text-2xl sm:text-3xl font-extrabold text-[#1F1F2E] dark:text-white leading-tight text-balance">
                {lang === 'vi' ? 'Nguyên Tố Hóa Học Nào ' : 'Which Chemical Element '}
                <span className="google-one-chem-gradient-text">
                  {lang === 'vi' ? 'Đại Diện Cho Bạn?' : 'Represents You?'}
                </span>
              </h3>

              <p className="text-sm sm:text-base text-[#4A4A68] dark:text-[#CBD5E1] leading-relaxed">
                Dự án tương tác biểu tượng của <strong className="text-[#1F1F2E] dark:text-white">BWAN Gen 6 — Chemistry Lab</strong>: giải mã bản sắc cá nhân qua 18 nguyên tố hóa học dựa trên 5 chiều sâu: tính cách, tư duy, làm việc nhóm, xử lý áp lực và phong cách sáng tạo.
              </p>

              <div className="pt-1 flex flex-wrap items-center gap-3 text-xs font-mono font-semibold text-[#D97706] dark:text-[#FBBF24]">
                <span>Ne · 10 (Khí hiếm Sáng tạo)</span>
                <span>·</span>
                <span>Fe · 26 (Bản lĩnh Thép)</span>
                <span>·</span>
                <span>Au · 79 (Kết nối Bền vững)</span>
              </div>

              <div className="pt-3 flex flex-wrap items-center gap-3">
                <button
                  type="button"
                  onClick={() => onOpenJoinModal('Ban Truyền Thông & Thiết Kế')}
                  className="inline-flex items-center gap-2 px-6 py-3 rounded-full google-one-chem-btn text-sm font-semibold active:scale-95 cursor-pointer whitespace-nowrap shrink-0"
                >
                  <span>
                    {lang === 'vi' ? 'Tham Gia Đội Ngũ Dự Án' : 'Join Project Team'}
                  </span>
                  <ArrowUpRight className="w-4 h-4" />
                </button>
              </div>
            </div>

            <div className="lg:col-span-6">
              <div className="rounded-2xl overflow-hidden border border-[#E5E2DC] dark:border-[#6C63FF]/40 shadow-md bg-[#0B0A16]">
                <img
                  src="/assets/aistudio/image_f5fb4f1c.png"
                  alt="Giao diện Hệ thống giải mã 18 Nguyên tố Nhân cách — BWAN Gen 6"
                  referrerPolicy="no-referrer"
                  className="w-full h-auto object-cover"
                />
              </div>
            </div>
          </div>

          {/* All Registered Projects Grid */}
          <div
            data-testid="club-projects-grid"
            className="mt-8 grid grid-cols-1 md:grid-cols-2 gap-6 items-stretch"
          >
            {filteredProjects.map((proj) => (
              <article
                key={proj.id}
                className="google-one-tonal-card rounded-[28px] p-6 sm:p-7 flex flex-col justify-between"
              >
                <div>
                  <div className="flex flex-wrap items-center gap-2 text-xs font-mono font-semibold">
                    <span className="text-[#6C63FF] dark:text-[#A39DFF]">
                      {proj.categoryLabel}
                    </span>
                    <span aria-hidden="true" className="text-[#9CA3AF]">·</span>
                    <span className="text-[#5F6368] dark:text-[#94A3B8]">
                      {proj.semester}
                    </span>
                    <span aria-hidden="true" className="text-[#9CA3AF]">·</span>
                    <span
                      className={
                        proj.status === 'ACTIVE'
                          ? 'text-[#0D9488] dark:text-[#34D399]'
                          : proj.status === 'UPCOMING'
                          ? 'text-[#D97706] dark:text-[#FBBF24]'
                          : 'text-[#0284C7] dark:text-[#38BDF8]'
                      }
                    >
                      {proj.statusLabel}
                    </span>
                  </div>

                  <h3 className="mt-3 font-display text-xl font-bold text-[#1F1F2E] dark:text-white leading-snug">
                    {proj.title}
                  </h3>

                  <p className="mt-2.5 text-sm text-[#4A4A68] dark:text-[#CBD5E1] leading-relaxed">
                    {proj.summary}
                  </p>
                </div>

                <div className="mt-6 pt-4 border-t border-[#DFDBD2] dark:border-[#6C63FF]/20">
                  <div className="flex flex-wrap items-center justify-between gap-2 text-xs font-mono font-semibold">
                    <span className="text-[#0284C7] dark:text-[#38BDF8]">
                      {proj.chemicalTheme}
                    </span>
                    <span className="text-[#D97706] dark:text-[#FBBF24] tabular-nums">
                      {proj.highlightMetric}
                    </span>
                  </div>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      {/* SECTION 03: UPCOMING EVENTS TIMELINE */}
      <section
        id="su-kien"
        className="py-20 px-4 sm:px-6 lg:px-8 bg-white dark:bg-[#0D0C1D] border-b border-[#EFECE6] dark:border-[#6C63FF]/20 transition-colors"
      >
        <div className="max-w-7xl mx-auto">
          <div className="text-center max-w-3xl mx-auto">
            <p className="text-xs font-mono font-semibold text-[#D97706] dark:text-[#FBBF24] tracking-wide">
              {lang === 'vi'
                ? '03. LỊCH TRÌNH SỰ KIỆN & HOẠT ĐỘNG CLB'
                : '03. UPCOMING CLUB EVENTS & WORKSHOPS'}
            </p>
            <h2 className="mt-2 font-display text-3xl sm:text-4xl font-bold text-[#1F1F2E] dark:text-white tracking-tight text-balance">
              {lang === 'vi' ? 'Sự Kiện Sắp Diễn Ra Tại ' : 'Upcoming Events at '}
              <span className="text-[#6C63FF] dark:text-[#A39DFF]">
                BWAN Club
              </span>
            </h2>
            <p className="mt-3 text-base text-[#4A4A68] dark:text-[#CBD5E1] leading-relaxed">
              {lang === 'vi'
                ? 'Đừng bỏ lỡ các buổi Workshop thực hành nuôi tinh thể, Ngày hội Giải mã Nguyên tố và Seminar chia sẻ kinh nghiệm học thuật cùng các thành viên CLB.'
                : 'Join our crystal-growing workshops, Element Decoding Day, and academic olympiad seminars.'}
            </p>
          </div>

          <div className="mt-10 grid grid-cols-1 lg:grid-cols-3 gap-6 items-stretch">
            {events.map((evt) => (
              <article
                key={evt.id}
                className="google-one-tonal-card rounded-[28px] p-6 sm:p-7 flex flex-col justify-between"
              >
                <div>
                  <div className="flex items-center justify-between gap-2 text-xs font-mono font-semibold">
                    <span className="inline-flex items-center gap-1.5 text-[#D97706] dark:text-[#FBBF24]">
                      <Calendar className="w-3.5 h-3.5" />
                      <span>{evt.dateLabel}</span>
                    </span>
                    <span className="text-[#0284C7] dark:text-[#38BDF8]">
                      {evt.formulaTag}
                    </span>
                  </div>

                  <h3 className="mt-3 font-display text-xl font-bold text-[#1F1F2E] dark:text-white leading-snug">
                    {evt.title}
                  </h3>

                  <p className="mt-2.5 text-sm text-[#4A4A68] dark:text-[#CBD5E1] leading-relaxed">
                    {evt.description}
                  </p>
                </div>

                <div className="mt-6 pt-4 border-t border-[#DFDBD2] dark:border-[#6C63FF]/20 space-y-3">
                  <div className="flex items-center gap-2 text-xs font-medium text-[#3C4043] dark:text-[#E2E8F0]">
                    <MapPin className="w-4 h-4 text-[#6C63FF] dark:text-[#A39DFF] shrink-0" />
                    <span>{evt.location}</span>
                  </div>

                  <div className="flex items-center justify-between pt-1">
                    <span className="text-xs font-mono font-semibold text-[#0D9488] dark:text-[#34D399] tabular-nums">
                      Còn {evt.spotsRemaining} suất tham dự
                    </span>
                    <button
                      type="button"
                      onClick={() => onOpenJoinModal('Ban Sự Kiện & Đối Ngoại')}
                      className="px-4 py-2 rounded-full google-one-chem-btn text-xs font-semibold cursor-pointer whitespace-nowrap shrink-0"
                    >
                      {lang === 'vi' ? 'Đăng ký tham dự' : 'Register'}
                    </button>
                  </div>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      {/* SECTION 04: DYNAMIC CATEGORY / MODULE SYNC ARCHITECTURE */}
      <section
        id="danh-muc"
        className="google-one-chem-section-wash py-20 px-4 sm:px-6 lg:px-8 border-b border-[#EFECE6] dark:border-[#6C63FF]/20 transition-colors"
      >
        <div className="max-w-5xl mx-auto">
          <div className="bg-white dark:bg-[#16142E] rounded-[32px] p-6 sm:p-10 border border-[#E5E2DC] dark:border-[#6C63FF]/30 shadow-xs">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-6 border-b border-[#EFECE6] dark:border-[#6C63FF]/20">
              <div>
                <div className="flex items-center gap-2 text-xs font-mono font-semibold text-[#6C63FF] dark:text-[#A39DFF]">
                  <FolderGit2 className="w-4 h-4 text-[#6C63FF] dark:text-[#A39DFF]" />
                  <span>04. CỔNG ĐỒNG BỘ MÃ NỀN DANH MỤC MỞ RỘNG</span>
                </div>
                <h2 className="mt-1.5 font-display text-2xl sm:text-3xl font-bold text-[#1F1F2E] dark:text-white text-balance">
                  {lang === 'vi'
                    ? 'Đồng Bộ Hóa Danh Mục & Dự Án Mới Của CLB'
                    : 'Synchronize New Club Categories & Projects'}
                </h2>
                <p className="mt-1 text-sm text-[#4A4A68] dark:text-[#CBD5E1]">
                  Khi bạn tải mã JSON hoặc nội dung của các danh mục tiếp theo lên, hệ thống sẽ tự động chuẩn hóa theo phong cách Google One Hóa Học (<code className="font-mono font-semibold text-[#6C63FF] dark:text-[#A39DFF]">#6c63ff</code>) và hiển thị tức thì.
                </p>
              </div>

              <button
                type="button"
                onClick={() => {
                  setPayloadText(SAMPLE_SYNC_JSON);
                  setCustomTitle(
                    '05. Triển Lãm Nhiếp Ảnh Vi Tinh Thể Hóa Học (Micro-Crystal Art)'
                  );
                  setSyncError(null);
                }}
                className="inline-flex items-center gap-1.5 px-4 py-2.5 rounded-full bg-[#F1F0FF] dark:bg-[#6C63FF]/25 hover:bg-[#E5E3FF] dark:hover:bg-[#6C63FF]/40 text-xs font-semibold text-[#6C63FF] dark:text-[#A39DFF] cursor-pointer whitespace-nowrap shrink-0 self-start sm:self-auto"
              >
                <Sparkles className="w-3.5 h-3.5" />
                <span>Nạp mã JSON danh mục mẫu</span>
              </button>
            </div>

            <form onSubmit={handleSyncSubmit} className="mt-6 space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label
                    htmlFor="sync-category-title"
                    className="block text-xs font-semibold text-[#3C4043] dark:text-[#E2E8F0] mb-1.5"
                  >
                    Tên danh mục / Dự án bổ sung
                  </label>
                  <input
                    id="sync-category-title"
                    type="text"
                    value={customTitle}
                    onChange={(e) => setCustomTitle(e.target.value)}
                    placeholder="VD: 05. Chuyên đề Tinh thể học..."
                    className="w-full px-4 py-2.5 rounded-xl bg-[#F8F9FA] dark:bg-[#0D0C1D] border border-[#DBD8D0] dark:border-[#6C63FF]/35 text-sm text-[#1F1F2E] dark:text-white placeholder-[#9CA3AF] focus:outline-none focus:border-[#6C63FF]"
                  />
                </div>

                <div>
                  <label
                    htmlFor="sync-category-group"
                    className="block text-xs font-semibold text-[#3C4043] dark:text-[#E2E8F0] mb-1.5"
                  >
                    Nhóm danh mục hiển thị
                  </label>
                  <select
                    id="sync-category-group"
                    value={customCategory}
                    onChange={(e) =>
                      setCustomCategory(e.target.value as typeof customCategory)
                    }
                    className="w-full px-4 py-2.5 rounded-xl bg-[#F8F9FA] dark:bg-[#0D0C1D] border border-[#DBD8D0] dark:border-[#6C63FF]/35 text-sm text-[#1F1F2E] dark:text-white focus:outline-none focus:border-[#6C63FF]"
                  >
                    <option value="du-an">Dự Án Thực Nghiệm</option>
                    <option value="su-kien">Sự Kiện Thường Niên</option>
                    <option value="nghien-cuu">Nghiên Cứu Khoa Học</option>
                    <option value="ung-dung">Ứng Dụng Hóa Học</option>
                  </select>
                </div>
              </div>

              <div>
                <label
                  htmlFor="sync-code-payload"
                  className="block text-xs font-semibold text-[#3C4043] dark:text-[#E2E8F0] mb-1.5"
                >
                  Mã cấu hình JSON hoặc mô tả chi tiết danh mục
                </label>
                <textarea
                  id="sync-code-payload"
                  rows={4}
                  value={payloadText}
                  onChange={(e) => setPayloadText(e.target.value)}
                  placeholder="Dán mã JSON hoặc nội dung mô tả danh mục mới của CLB vào đây để đồng bộ..."
                  className="w-full rounded-2xl bg-[#F8F9FA] dark:bg-[#0D0C1D] border border-[#DBD8D0] dark:border-[#6C63FF]/35 p-3.5 font-mono text-xs text-[#1F1F2E] dark:text-white placeholder-[#9CA3AF] focus:outline-none focus:border-[#6C63FF]"
                />
              </div>

              {syncError && (
                <p role="alert" className="text-xs text-[#DC2626] dark:text-[#F87171] font-semibold">
                  {syncError}
                </p>
              )}

              {syncSuccess && (
                <div
                  role="status"
                  className="flex items-center gap-2 text-xs text-[#0D9488] dark:text-[#34D399] bg-[#F0FDFA] dark:bg-[#064E3B]/40 border border-[#99F6E4] dark:border-[#34D399]/40 px-4 py-3 rounded-xl font-semibold"
                >
                  <CheckCircle className="w-4 h-4 shrink-0" />
                  <span>{syncSuccess}</span>
                </div>
              )}

              <div className="pt-2">
                <button
                  type="submit"
                  className="inline-flex items-center justify-center gap-2 px-7 py-3.5 rounded-full google-one-chem-btn text-sm font-semibold active:scale-95 cursor-pointer whitespace-nowrap shrink-0"
                >
                  <UploadCloud className="w-4 h-4" />
                  <span>Đồng Bộ Danh Mục Lên Website</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      </section>
    </>
  );
};
