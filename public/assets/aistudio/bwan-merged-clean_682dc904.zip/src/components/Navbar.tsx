import React, { useState } from 'react';
import { Menu, X, Sun, Moon, Globe, HeartHandshake } from 'lucide-react';
import { BwanHexLogo } from './BwanHexLogo';

export type AppLanguage = 'vi' | 'en';

interface NavbarProps {
  onOpenJoinModal: (defaultDept?: string) => void;
  isDark: boolean;
  onToggleTheme: () => void;
  lang: AppLanguage;
  onToggleLang: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  onOpenJoinModal,
  isDark,
  onToggleTheme,
  lang,
  onToggleLang,
}) => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const labels = {
    overview: lang === 'vi' ? 'Tổng quan' : 'Overview',
    divisions: lang === 'vi' ? 'Phân ban' : 'Divisions',
    projects: lang === 'vi' ? 'Dự án' : 'Projects',
    events: lang === 'vi' ? 'Sự kiện' : 'Events',
    donate: lang === 'vi' ? 'Quyên góp' : 'Donate',
    leaderboard: lang === 'vi' ? 'BXH Top Donate' : 'Leaderboard',
    themeLabel:
      lang === 'vi'
        ? isDark
          ? 'Sáng'
          : 'Tối'
        : isDark
        ? 'Light'
        : 'Dark',
    langLabel: lang === 'vi' ? 'VI' : 'EN',
    register: lang === 'vi' ? 'Đăng ký' : 'Join Club',
  };

  return (
    <header className="sticky top-0 z-40 bg-white/95 dark:bg-[#0D0C1D]/95 backdrop-blur-md border-b border-[#E5E7EB] dark:border-[#6C63FF]/25 transition-colors">
      <div className="max-w-7xl mx-auto flex items-center justify-between gap-6 px-4 sm:px-6 lg:px-8 h-16">
        {/* Zone 1: Transparent Hexagonal Club Logo + Dual-Tone Wordmark */}
        <a
          href="#gioi-thieu"
          className="inline-flex items-center gap-2.5 text-lg sm:text-xl font-bold tracking-tight text-[#1F1F2E] dark:text-white whitespace-nowrap shrink-0 focus-visible:outline-2 focus-visible:outline-[#6C63FF] rounded-lg"
        >
          <BwanHexLogo className="w-8 h-8" />
          <span className="font-display">
            <span className="text-[#6C63FF] font-bold">BWAN</span>{' '}
            <span className="font-semibold text-[#4A4A68] dark:text-[#CBD5E1]">
              Club
            </span>
          </span>
        </a>

        {/* Zone 2: Navigation links + Theme & Language items */}
        <nav
          aria-label="Điều hướng chính"
          className="hidden lg:flex items-center gap-5 text-sm font-medium text-[#5F6368] dark:text-[#CBD5E1]"
        >
          <a
            href="#gioi-thieu"
            className="text-[#6C63FF] border-b-2 border-[#6C63FF] py-5 transition-colors whitespace-nowrap shrink-0"
          >
            {labels.overview}
          </a>
          <a
            href="#ve-clb"
            className="hover:text-[#1F1F2E] dark:hover:text-white py-5 transition-colors whitespace-nowrap shrink-0"
          >
            {labels.divisions}
          </a>
          <a
            href="#du-an"
            className="hover:text-[#1F1F2E] dark:hover:text-white py-5 transition-colors whitespace-nowrap shrink-0"
          >
            {labels.projects}
          </a>
          <a
            href="#su-kien"
            className="hover:text-[#1F1F2E] dark:hover:text-white py-5 transition-colors whitespace-nowrap shrink-0"
          >
            {labels.events}
          </a>
          <a
            href="#quyen-gop"
            className="inline-flex items-center gap-1.5 font-semibold text-[#6C63FF] dark:text-[#A39DFF] hover:opacity-85 py-5 transition-colors whitespace-nowrap shrink-0"
          >
            <HeartHandshake className="w-4 h-4" />
            <span>{labels.donate}</span>
          </a>
          <a
            href="#leaderboard-section"
            className="hover:text-[#1F1F2E] dark:hover:text-white py-5 transition-colors whitespace-nowrap shrink-0"
          >
            {labels.leaderboard}
          </a>

          {/* Light / Dark Mode Switch */}
          <button
            type="button"
            onClick={onToggleTheme}
            aria-label={
              isDark
                ? 'Chuyển sang giao diện Sáng'
                : 'Chuyển sang giao diện Tối'
            }
            className="inline-flex items-center gap-1.5 hover:text-[#6C63FF] dark:hover:text-[#A39DFF] py-2 transition-colors cursor-pointer whitespace-nowrap shrink-0"
          >
            {isDark ? (
              <Sun className="w-4 h-4 text-[#F59E0B]" />
            ) : (
              <Moon className="w-4 h-4 text-[#6C63FF]" />
            )}
            <span>{labels.themeLabel}</span>
          </button>

          {/* Language Selector (VI / EN) */}
          <button
            type="button"
            onClick={onToggleLang}
            aria-label="Chuyển đổi ngôn ngữ Tiếng Việt hoặc Tiếng Anh"
            className="inline-flex items-center gap-1.5 hover:text-[#6C63FF] dark:hover:text-[#A39DFF] py-2 transition-colors cursor-pointer whitespace-nowrap shrink-0"
          >
            <Globe className="w-4 h-4 text-[#6C63FF]" />
            <span>{labels.langLabel}</span>
          </button>
        </nav>

        {/* Zone 3: Capsule actions */}
        <div className="flex items-center gap-2.5 shrink-0">
          <a
            href="#quyen-gop"
            className="hidden sm:inline-flex items-center gap-1.5 px-4 py-2 text-xs sm:text-sm font-semibold rounded-full border border-[#6C63FF]/35 text-[#6C63FF] dark:text-[#A39DFF] hover:bg-[#6C63FF]/10 transition-colors whitespace-nowrap shrink-0"
          >
            <HeartHandshake className="w-4 h-4" />
            <span>{labels.donate}</span>
          </a>

          <button
            type="button"
            onClick={() => onOpenJoinModal('Ban Chuyên Môn & Phòng Lab')}
            className="px-5 py-2 text-sm font-semibold google-one-chem-btn rounded-full active:scale-95 whitespace-nowrap shrink-0 cursor-pointer focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#6C63FF]"
          >
            {labels.register}
          </button>

          <button
            type="button"
            aria-label={
              mobileMenuOpen ? 'Đóng menu điều hướng' : 'Mở menu điều hướng'
            }
            aria-expanded={mobileMenuOpen}
            onClick={() => setMobileMenuOpen((prev) => !prev)}
            className="lg:hidden p-2 rounded-lg text-[#5F6368] dark:text-[#CBD5E1] hover:text-[#1F1F2E] dark:hover:text-white hover:bg-[#F3F4F6] dark:hover:bg-[#191632] transition-colors cursor-pointer"
          >
            {mobileMenuOpen ? (
              <X className="w-5 h-5" />
            ) : (
              <Menu className="w-5 h-5" />
            )}
          </button>
        </div>
      </div>

      {/* Responsive Mobile Navigation Drawer */}
      {mobileMenuOpen && (
        <nav
          aria-label="Điều hướng di động"
          className="lg:hidden bg-white dark:bg-[#121026] border-b border-[#E5E7EB] dark:border-[#6C63FF]/30 px-4 pt-2 pb-4 space-y-1"
        >
          <a
            href="#gioi-thieu"
            onClick={() => setMobileMenuOpen(false)}
            className="block px-3.5 py-2.5 rounded-xl text-sm font-semibold text-[#6C63FF] bg-[#F1F0FF] dark:bg-[#6C63FF]/20"
          >
            {labels.overview}
          </a>
          <a
            href="#ve-clb"
            onClick={() => setMobileMenuOpen(false)}
            className="block px-3.5 py-2.5 rounded-xl text-sm font-medium text-[#4A4A68] dark:text-[#CBD5E1] hover:bg-[#F3F4F6] dark:hover:bg-[#191632]"
          >
            {labels.divisions}
          </a>
          <a
            href="#du-an"
            onClick={() => setMobileMenuOpen(false)}
            className="block px-3.5 py-2.5 rounded-xl text-sm font-medium text-[#4A4A68] dark:text-[#CBD5E1] hover:bg-[#F3F4F6] dark:hover:bg-[#191632]"
          >
            {labels.projects}
          </a>
          <a
            href="#su-kien"
            onClick={() => setMobileMenuOpen(false)}
            className="block px-3.5 py-2.5 rounded-xl text-sm font-medium text-[#4A4A68] dark:text-[#CBD5E1] hover:bg-[#F3F4F6] dark:hover:bg-[#191632]"
          >
            {labels.events}
          </a>
          <a
            href="#quyen-gop"
            onClick={() => setMobileMenuOpen(false)}
            className="block px-3.5 py-2.5 rounded-xl text-sm font-semibold text-[#6C63FF] dark:text-[#A39DFF] hover:bg-[#F3F4F6] dark:hover:bg-[#191632]"
          >
            {labels.donate}
          </a>
          <a
            href="#leaderboard-section"
            onClick={() => setMobileMenuOpen(false)}
            className="block px-3.5 py-2.5 rounded-xl text-sm font-medium text-[#4A4A68] dark:text-[#CBD5E1] hover:bg-[#F3F4F6] dark:hover:bg-[#191632]"
          >
            {labels.leaderboard}
          </a>

          <div className="pt-2 mt-2 border-t border-[#E5E7EB] dark:border-[#6C63FF]/20 flex items-center gap-3 px-2">
            <button
              type="button"
              onClick={onToggleTheme}
              className="flex-1 inline-flex items-center justify-center gap-2 py-2.5 rounded-xl bg-[#F4F2EE] dark:bg-[#191632] text-xs font-semibold text-[#1F1F2E] dark:text-white cursor-pointer"
            >
              {isDark ? (
                <Sun className="w-4 h-4 text-[#F59E0B]" />
              ) : (
                <Moon className="w-4 h-4 text-[#6C63FF]" />
              )}
              <span>{labels.themeLabel}</span>
            </button>

            <button
              type="button"
              onClick={onToggleLang}
              className="flex-1 inline-flex items-center justify-center gap-2 py-2.5 rounded-xl bg-[#F4F2EE] dark:bg-[#191632] text-xs font-semibold text-[#1F1F2E] dark:text-white cursor-pointer"
            >
              <Globe className="w-4 h-4 text-[#6C63FF]" />
              <span>{labels.langLabel}</span>
            </button>
          </div>
        </nav>
      )}
    </header>
  );
};
