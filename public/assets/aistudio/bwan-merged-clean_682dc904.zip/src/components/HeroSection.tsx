import React from 'react';
import { ArrowRight, Atom, FlaskConical, Calendar } from 'lucide-react';
import { motion } from 'motion/react';
import { BwanHexLogo } from './BwanHexLogo';
import { AppLanguage } from './Navbar';

interface HeroSectionProps {
  onOpenJoinModal: (defaultDept?: string) => void;
  totalProjectsCount: number;
  totalEventsCount: number;
  lang: AppLanguage;
}

export const HeroSection: React.FC<HeroSectionProps> = ({
  onOpenJoinModal,
  totalProjectsCount,
  totalEventsCount,
  lang,
}) => {
  return (
    <section
      id="gioi-thieu"
      className="google-one-chem-hero pt-14 pb-20 sm:pt-20 sm:pb-24 px-4 sm:px-6 lg:px-8 border-b border-[#E5E7EB]/80 dark:border-[#6C63FF]/20 transition-colors"
    >
      <div className="max-w-5xl mx-auto text-center">
        {/* Clean Transparent Hexagonal Logo + BWAN Club Title */}
        <motion.div
          initial={{ opacity: 0, y: 12 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.4, ease: [0.16, 1, 0.3, 1] }}
          className="inline-flex items-center justify-center gap-3 mb-6"
        >
          <BwanHexLogo className="w-10 h-10 sm:w-11 sm:h-11" />
          <span className="font-display text-2xl sm:text-3xl tracking-tight">
            <span className="font-extrabold text-[#6C63FF]">BWAN</span>{' '}
            <span className="font-bold text-[#1F1F2E] dark:text-white">
              Club
            </span>
          </span>
        </motion.div>

        {/* Main Display Headline */}
        <motion.h1
          initial={{ opacity: 0, y: 14 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.45, delay: 0.05, ease: [0.16, 1, 0.3, 1] }}
          className="font-display font-extrabold text-[#1F1F2E] dark:text-white tracking-tight text-balance mx-auto max-w-4xl text-4xl sm:text-5xl lg:text-[54px] leading-[1.16]"
        >
          {lang === 'vi' ? (
            <>
              Đam mê lớn hơn và{' '}
              <span className="google-one-chem-gradient-text">
                Phản ứng Sáng tạo
              </span>{' '}
              trong một Câu lạc bộ Hóa Học
            </>
          ) : (
            <>
              Greater Passion and{' '}
              <span className="google-one-chem-gradient-text">
                Creative Reactions
              </span>{' '}
              in One Chemistry Club
            </>
          )}
        </motion.h1>

        {/* Clean Centered Subheadline */}
        <motion.p
          initial={{ opacity: 0, y: 14 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.45, delay: 0.1, ease: [0.16, 1, 0.3, 1] }}
          className="mt-6 text-base sm:text-[17px] font-normal text-[#4A4A68] dark:text-[#CBD5E1] max-w-2xl mx-auto leading-[1.65]"
        >
          {lang === 'vi'
            ? 'Không gian chính thức giới thiệu các dự án thực nghiệm, đêm hội Hóa phát quang, chuỗi sự kiện học thuật và hệ sinh thái 18 nguyên tố nhân cách của BWAN Club.'
            : 'The official portal showcasing experimental projects, Chemiluminescence showcases, academic seminars, and the 18-Element Personality ecosystem of BWAN Club.'}
        </motion.p>

        {/* Single Dominant Google One Capsule Button in #6c63ff */}
        <motion.div
          initial={{ opacity: 0, y: 14 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.45, delay: 0.15, ease: [0.16, 1, 0.3, 1] }}
          className="mt-8 flex flex-wrap items-center justify-center gap-4"
        >
          <button
            type="button"
            onClick={() => onOpenJoinModal('Ban Chuyên Môn & Phòng Lab')}
            className="inline-flex items-center gap-2.5 px-7 py-3.5 rounded-full google-one-chem-btn font-semibold text-sm sm:text-base active:scale-95 cursor-pointer whitespace-nowrap shrink-0"
          >
            <span>
              {lang === 'vi' ? 'Đăng ký tham gia ngay' : 'Join the Club Now'}
            </span>
            <ArrowRight className="w-4 h-4" />
          </button>

          <a
            href="#du-an"
            className="inline-flex items-center gap-2 px-6 py-3.5 rounded-full bg-white dark:bg-[#16142E] hover:bg-[#F4F2EE] dark:hover:bg-[#1E1B3D] text-[#6C63FF] dark:text-[#A39DFF] border border-[#DBD8D0] dark:border-[#6C63FF]/35 font-semibold text-sm sm:text-base transition-colors whitespace-nowrap shrink-0"
          >
            <span>
              {lang === 'vi' ? 'Khám phá dự án CLB' : 'Explore Club Projects'}
            </span>
          </a>
        </motion.div>

        {/* 3 Clean Google One Tonal Proof Cards below the hero with refined Be Vietnam Pro typography */}
        <div className="mt-14 pt-8 border-t border-[#E5E2DC] dark:border-[#6C63FF]/20 grid grid-cols-1 sm:grid-cols-3 gap-6 text-left max-w-4xl mx-auto">
          <div className="bg-white/90 dark:bg-[#16142E]/90 backdrop-blur-xs rounded-2xl p-6 border border-[#E5E2DC] dark:border-[#6C63FF]/25 shadow-2xs transition-all hover:border-[#6C63FF]/40">
            <div className="flex items-center justify-between text-xs font-semibold tracking-wide text-[#6C63FF] dark:text-[#A39DFF]">
              <span className="bg-[#F1F0FF] dark:bg-[#6C63FF]/20 px-2.5 py-1 rounded-md">
                Pt · 78 / Ne · 10
              </span>
              <Atom className="w-4 h-4 text-[#6C63FF] dark:text-[#A39DFF]" />
            </div>
            <p className="mt-3.5 font-display text-lg sm:text-[19px] font-bold text-[#1F1F2E] dark:text-white tracking-tight tabular-nums">
              {lang === 'vi' ? '6 Thế Hệ (Gen 1–6)' : '6 Generations (Gen 1–6)'}
            </p>
            <p className="mt-1.5 text-[13.5px] sm:text-sm font-normal text-[#4A4A68] dark:text-[#CBD5E1] leading-relaxed">
              {lang === 'vi'
                ? 'Hơn 180+ thành viên & cựu học sinh chuyên Hóa toàn trường'
                : '180+ active members & chemistry alumni across generations'}
            </p>
          </div>

          <div className="bg-white/90 dark:bg-[#16142E]/90 backdrop-blur-xs rounded-2xl p-6 border border-[#E5E2DC] dark:border-[#6C63FF]/25 shadow-2xs transition-all hover:border-[#0284C7]/40">
            <div className="flex items-center justify-between text-xs font-semibold tracking-wide text-[#0284C7] dark:text-[#38BDF8]">
              <span className="bg-[#E0F2FE] dark:bg-[#0284C7]/20 px-2.5 py-1 rounded-md">
                Fe · 26 / Cu · 29
              </span>
              <FlaskConical className="w-4 h-4 text-[#0284C7] dark:text-[#38BDF8]" />
            </div>
            <p
              data-testid="hero-projects-count"
              className="mt-3.5 font-display text-lg sm:text-[19px] font-bold text-[#1F1F2E] dark:text-white tracking-tight tabular-nums"
            >
              {totalProjectsCount}{' '}
              {lang === 'vi' ? 'Dự Án & Danh Mục' : 'Projects & Modules'}
            </p>
            <p className="mt-1.5 text-[13.5px] sm:text-sm font-normal text-[#4A4A68] dark:text-[#CBD5E1] leading-relaxed">
              {lang === 'vi'
                ? 'Từ ứng dụng Giải mã 18 Nguyên tố đến Hóa phát quang & Tinh thể'
                : 'From the 18-Element Personality Test to Chemiluminescence & Crystals'}
            </p>
          </div>

          <div className="bg-white/90 dark:bg-[#16142E]/90 backdrop-blur-xs rounded-2xl p-6 border border-[#E5E2DC] dark:border-[#6C63FF]/25 shadow-2xs transition-all hover:border-[#D97706]/40">
            <div className="flex items-center justify-between text-xs font-semibold tracking-wide text-[#D97706] dark:text-[#FBBF24]">
              <span className="bg-[#FEF3C7] dark:bg-[#D97706]/20 px-2.5 py-1 rounded-md">
                Au · 79 / Ag · 47
              </span>
              <Calendar className="w-4 h-4 text-[#D97706] dark:text-[#FBBF24]" />
            </div>
            <p className="mt-3.5 font-display text-lg sm:text-[19px] font-bold text-[#1F1F2E] dark:text-white tracking-tight tabular-nums">
              {totalEventsCount}{' '}
              {lang === 'vi' ? 'Sự Kiện Trọng Điểm' : 'Featured Events'}
            </p>
            <p className="mt-1.5 text-[13.5px] sm:text-sm font-normal text-[#4A4A68] dark:text-[#CBD5E1] leading-relaxed">
              {lang === 'vi'
                ? 'Workshop nuôi tinh thể, Ngày hội tuyển quân & Seminar học thuật'
                : 'Crystal growing workshops, Recruitment day & Academic seminars'}
            </p>
          </div>
        </div>
      </div>
    </section>
  );
};
