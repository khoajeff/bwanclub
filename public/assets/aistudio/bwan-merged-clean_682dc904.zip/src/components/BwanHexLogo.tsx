import React from 'react';

interface BwanHexLogoProps {
  className?: string;
}

/**
 * Transparent-background BWAN Hexagonal Logo matching the uploaded geometric purple hexagon
 * without any black background rectangle.
 */
export const BwanHexLogo: React.FC<BwanHexLogoProps> = ({ className = 'w-9 h-9' }) => {
  return (
    <svg
      viewBox="0 0 100 100"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      className={`${className} shrink-0`}
      role="img"
      aria-label="Logo CLB Hóa Học BWAN"
    >
      <defs>
        <linearGradient id="bwanHexGradMain" x1="12" y1="8" x2="88" y2="92" gradientUnits="userSpaceOnUse">
          <stop offset="0%" stopColor="#7C74FF" />
          <stop offset="55%" stopColor="#6C63FF" />
          <stop offset="100%" stopColor="#463FB8" />
        </linearGradient>
        <linearGradient id="bwanHexGradShard" x1="20" y1="15" x2="80" y2="85" gradientUnits="userSpaceOnUse">
          <stop offset="0%" stopColor="#8B84FF" />
          <stop offset="100%" stopColor="#554CE0" />
        </linearGradient>
      </defs>

      {/* Top-Left Facet */}
      <path
        d="M49.2 6.5 L13.5 27.2 C12.4 27.8 11.8 29 11.8 30.3 L34.2 55.2 L48.8 22.8 C49.5 21.3 51.5 21.1 52.5 22.4 L62.8 34.4 L69.8 18.8 L51.6 6.5 C50.8 6 49.9 6 49.2 6.5 Z"
        fill="url(#bwanHexGradMain)"
      />

      {/* Center Diamond Shard */}
      <path
        d="M50.6 26.8 L36.6 58.0 L47.2 69.8 L61.2 38.2 L50.6 26.8 Z"
        fill="url(#bwanHexGradShard)"
      />

      {/* Left Lower Facet */}
      <path
        d="M11.8 34.8 L11.8 69.2 C11.8 70.6 12.5 71.8 13.7 72.5 L24.5 78.8 L33.8 58.2 L11.8 34.8 Z"
        fill="url(#bwanHexGradMain)"
      />

      {/* Bottom Facet */}
      <path
        d="M35.8 60.8 L26.8 80.5 L48.2 93.2 C49.4 93.9 50.9 93.9 52.1 93.2 L59.8 88.6 L35.8 60.8 Z"
        fill="url(#bwanHexGradMain)"
      />

      {/* Right Upper Facet */}
      <path
        d="M72.5 20.6 L65.2 36.8 L88.2 63.4 L88.2 30.8 C88.2 29.4 87.5 28.2 86.3 27.5 L72.5 20.6 Z"
        fill="url(#bwanHexGradMain)"
      />

      {/* Right Lower Facet */}
      <path
        d="M63.4 40.8 L49.4 72.2 L62.5 86.8 L86.3 72.5 C87.5 71.8 88.2 70.6 88.2 69.2 L88.2 67.6 L63.4 40.8 Z"
        fill="url(#bwanHexGradShard)"
      />
    </svg>
  );
};
