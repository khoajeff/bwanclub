import React, { useState, useEffect } from 'react';
import { X, CheckCircle2 } from 'lucide-react';
import { BwanHexLogo } from './BwanHexLogo';

export interface MemberRegistration {
  id: string;
  fullName: string;
  email: string;
  gradeClass: string;
  division: string;
  favoriteElement: string;
  registeredAt: string;
}

interface JoinClubModalProps {
  isOpen: boolean;
  defaultDivision: string;
  onClose: () => void;
  onRegisterMember: (member: MemberRegistration) => void;
  registeredMembers: MemberRegistration[];
}

export const JoinClubModal: React.FC<JoinClubModalProps> = ({
  isOpen,
  defaultDivision,
  onClose,
  onRegisterMember,
  registeredMembers,
}) => {
  const [fullName, setFullName] = useState('');
  const [email, setEmail] = useState('');
  const [gradeClass, setGradeClass] = useState('Lớp 11 Chuyên Hóa');
  const [division, setDivision] = useState(
    defaultDivision || 'Ban Chuyên Môn & Phòng Lab'
  );
  const [favoriteElement, setFavoriteElement] = useState(
    'Fe · 26 (Bản lĩnh Thép)'
  );
  const [formError, setFormError] = useState<string | null>(null);
  const [submittedSuccess, setSubmittedSuccess] = useState(false);

  useEffect(() => {
    if (defaultDivision) {
      setDivision(defaultDivision);
    }
  }, [defaultDivision]);

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setFormError(null);

    if (!fullName.trim() || fullName.trim().length < 2) {
      setFormError('Vui lòng nhập họ và tên hoặc biệt danh của bạn.');
      return;
    }

    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!email.trim() || !emailRegex.test(email.trim())) {
      setFormError('Vui lòng nhập địa chỉ email hợp lệ.');
      return;
    }

    const newMember: MemberRegistration = {
      id: `mem-${Date.now()}`,
      fullName: fullName.trim(),
      email: email.trim(),
      gradeClass: gradeClass.trim() || 'Gen 6 · BWAN',
      division,
      favoriteElement: favoriteElement.trim() || 'Ne · 10',
      registeredAt: 'Vừa đăng ký',
    };

    onRegisterMember(newMember);
    setSubmittedSuccess(true);
    setFullName('');
    setEmail('');
  };

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-labelledby="join-club-modal-title"
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-xs"
    >
      <div className="bg-white dark:bg-[#16142E] rounded-[32px] max-w-lg w-full p-6 sm:p-8 border border-[#E5E2DC] dark:border-[#6C63FF]/40 shadow-2xl max-h-[90vh] overflow-y-auto text-[#1F1F2E] dark:text-white">
        <div className="flex items-center justify-between gap-4 pb-4 border-b border-[#EFECE6] dark:border-[#6C63FF]/25">
          <div className="flex items-center gap-3">
            <BwanHexLogo className="w-9 h-9" />
            <div>
              <h2
                id="join-club-modal-title"
                className="font-display text-xl font-bold text-[#1F1F2E] dark:text-white"
              >
                Đăng Ký Gia Nhập BWAN Gen 6
              </h2>
              <p className="text-xs text-[#6C63FF] dark:text-[#A39DFF] font-medium mt-0.5">
                Câu lạc bộ Hóa Học Hiện Đại · BWAN Club
              </p>
            </div>
          </div>

          <button
            type="button"
            aria-label="Đóng cửa sổ đăng ký"
            onClick={() => {
              setSubmittedSuccess(false);
              setFormError(null);
              onClose();
            }}
            className="p-2 rounded-full text-[#5F6368] dark:text-[#CBD5E1] hover:text-[#1F1F2E] dark:hover:text-white hover:bg-[#F3F4F6] dark:hover:bg-[#231F44] transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {submittedSuccess ? (
          <div className="py-6 text-center space-y-4">
            <div className="w-12 h-12 rounded-full bg-[#F0FDFA] dark:bg-[#064E3B] text-[#0D9488] dark:text-[#34D399] border border-[#99F6E4] dark:border-[#34D399]/40 flex items-center justify-center mx-auto">
              <CheckCircle2 className="w-6 h-6" />
            </div>
            <h3 className="font-display text-lg font-bold text-[#1F1F2E] dark:text-white">
              Đăng ký ứng tuyển thành công!
            </h3>
            <p className="text-sm text-[#4A4A68] dark:text-[#CBD5E1]">
              Hồ sơ của bạn đã được ghi nhận vào danh sách thành viên{' '}
              <strong className="text-[#6C63FF] dark:text-[#A39DFF]">
                {division}
              </strong>
              .
            </p>
            <div className="pt-2 flex justify-center gap-3">
              <button
                type="button"
                onClick={() => setSubmittedSuccess(false)}
                className="px-5 py-2.5 rounded-full bg-[#F4F2EE] dark:bg-[#231F44] hover:bg-[#EAE7E0] text-xs font-semibold text-[#1F1F2E] dark:text-white cursor-pointer"
              >
                Đăng ký thêm
              </button>
              <button
                type="button"
                onClick={() => {
                  setSubmittedSuccess(false);
                  onClose();
                }}
                className="px-6 py-2.5 rounded-full google-one-chem-btn text-xs font-semibold cursor-pointer"
              >
                Hoàn tất
              </button>
            </div>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="mt-5 space-y-4" noValidate>
            <div>
              <label
                htmlFor="member-fullname"
                className="block text-xs font-semibold text-[#3C4043] dark:text-[#E2E8F0] mb-1.5"
              >
                Họ và tên hoặc biệt danh của bạn *
              </label>
              <input
                id="member-fullname"
                type="text"
                value={fullName}
                onChange={(e) => setFullName(e.target.value)}
                placeholder="VD: Minh Anh — BWAN Gen 6..."
                className="w-full px-4 py-2.5 rounded-xl bg-[#F8F9FA] dark:bg-[#0D0C1D] border border-[#DBD8D0] dark:border-[#6C63FF]/35 text-sm text-[#1F1F2E] dark:text-white placeholder-[#9CA3AF] focus:outline-none focus:border-[#6C63FF]"
              />
            </div>

            <div>
              <label
                htmlFor="member-email"
                className="block text-xs font-semibold text-[#3C4043] dark:text-[#E2E8F0] mb-1.5"
              >
                Email liên hệ *
              </label>
              <input
                id="member-email"
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="minhanh@bwanclub.edu.vn"
                className="w-full px-4 py-2.5 rounded-xl bg-[#F8F9FA] dark:bg-[#0D0C1D] border border-[#DBD8D0] dark:border-[#6C63FF]/35 text-sm text-[#1F1F2E] dark:text-white placeholder-[#9CA3AF] focus:outline-none focus:border-[#6C63FF]"
              />
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label
                  htmlFor="member-division"
                  className="block text-xs font-semibold text-[#3C4043] dark:text-[#E2E8F0] mb-1.5"
                >
                  Phân ban ứng tuyển
                </label>
                <select
                  id="member-division"
                  value={division}
                  onChange={(e) => setDivision(e.target.value)}
                  className="w-full px-3.5 py-2.5 rounded-xl bg-[#F8F9FA] dark:bg-[#0D0C1D] border border-[#DBD8D0] dark:border-[#6C63FF]/35 text-sm text-[#1F1F2E] dark:text-white focus:outline-none focus:border-[#6C63FF]"
                >
                  <option value="Ban Chuyên Môn & Phòng Lab">
                    Ban Chuyên Môn & Phòng Lab (Pt · 78)
                  </option>
                  <option value="Ban Truyền Thông & Thiết Kế">
                    Ban Truyền Thông & Thiết Kế (Ne · 10)
                  </option>
                  <option value="Ban Sự Kiện & Đối Ngoại">
                    Ban Sự Kiện & Đối Ngoại (Au · 79)
                  </option>
                </select>
              </div>

              <div>
                <label
                  htmlFor="member-grade"
                  className="block text-xs font-semibold text-[#3C4043] dark:text-[#E2E8F0] mb-1.5"
                >
                  Khối / Lớp
                </label>
                <input
                  id="member-grade"
                  type="text"
                  value={gradeClass}
                  onChange={(e) => setGradeClass(e.target.value)}
                  className="w-full px-3.5 py-2.5 rounded-xl bg-[#F8F9FA] dark:bg-[#0D0C1D] border border-[#DBD8D0] dark:border-[#6C63FF]/35 text-sm text-[#1F1F2E] dark:text-white focus:outline-none focus:border-[#6C63FF]"
                />
              </div>
            </div>

            <div>
              <label
                htmlFor="member-element"
                className="block text-xs font-semibold text-[#3C4043] dark:text-[#E2E8F0] mb-1.5"
              >
                Nguyên tố hóa học đại diện yêu thích
              </label>
              <input
                id="member-element"
                type="text"
                value={favoriteElement}
                onChange={(e) => setFavoriteElement(e.target.value)}
                className="w-full px-4 py-2.5 rounded-xl bg-[#F8F9FA] dark:bg-[#0D0C1D] border border-[#DBD8D0] dark:border-[#6C63FF]/35 text-sm text-[#1F1F2E] dark:text-white focus:outline-none focus:border-[#6C63FF]"
              />
            </div>

            {formError && (
              <p role="alert" className="text-xs text-[#DC2626] dark:text-[#F87171] font-semibold">
                {formError}
              </p>
            )}

            <div className="pt-2 flex items-center justify-end gap-3">
              <button
                type="button"
                onClick={onClose}
                className="px-5 py-2.5 rounded-full bg-[#F4F2EE] dark:bg-[#231F44] hover:bg-[#EAE7E0] text-xs font-semibold text-[#4A4A68] dark:text-[#CBD5E1] cursor-pointer"
              >
                Hủy
              </button>
              <button
                type="submit"
                className="px-6 py-2.5 rounded-full google-one-chem-btn text-xs font-semibold cursor-pointer"
              >
                Đăng ký ngay →
              </button>
            </div>
          </form>
        )}

        {/* Recent Members Roster */}
        <div className="mt-6 pt-5 border-t border-[#EFECE6] dark:border-[#6C63FF]/25">
          <p className="text-xs font-semibold text-[#5F6368] dark:text-[#94A3B8] mb-2.5">
            Thành viên vừa đăng ký ({registeredMembers.length}):
          </p>
          <div className="space-y-2 max-h-28 overflow-y-auto">
            {registeredMembers.map((m) => (
              <div
                key={m.id}
                className="flex items-center justify-between text-xs bg-[#F4F2EE] dark:bg-[#0D0C1D] px-3.5 py-2 rounded-xl border border-[#E5E2DC] dark:border-[#6C63FF]/25"
              >
                <div>
                  <span className="font-semibold text-[#1F1F2E] dark:text-white">
                    {m.fullName}
                  </span>
                  <span className="text-[#5F6368] dark:text-[#94A3B8]">
                    {' '}
                    · {m.favoriteElement}
                  </span>
                </div>
                <span className="font-mono font-semibold text-[#6C63FF] dark:text-[#A39DFF]">
                  {m.division}
                </span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
