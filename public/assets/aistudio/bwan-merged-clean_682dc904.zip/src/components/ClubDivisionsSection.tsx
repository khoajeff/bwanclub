import React from 'react';
import { CLUB_DEPARTMENTS } from '../utils/chemistryEngine';
import { Check, ArrowRight } from 'lucide-react';
import { AppLanguage } from './Navbar';

interface ClubDivisionsSectionProps {
  onSelectDivision: (deptName: string) => void;
  lang: AppLanguage;
}

export const ClubDivisionsSection: React.FC<ClubDivisionsSectionProps> = ({
  onSelectDivision,
  lang,
}) => {
  return (
    <section
      id="ve-clb"
      className="py-20 px-4 sm:px-6 lg:px-8 bg-white dark:bg-[#0D0C1D] border-b border-[#EFECE6] dark:border-[#6C63FF]/20 transition-colors"
    >
      <div className="max-w-6xl mx-auto">
        {/* Centered Section Header */}
        <div className="text-center max-w-2xl mx-auto">
          <h2 className="font-display text-3xl sm:text-4xl font-bold text-[#1F1F2E] dark:text-white tracking-tight text-balance">
            {lang === 'vi'
              ? 'Các Phân Ban của CLB Hóa Học'
              : 'Chemistry Club Divisions'}
          </h2>
          <p className="mt-3 text-base text-[#4A4A68] dark:text-[#CBD5E1]">
            {lang === 'vi'
              ? 'Thêm trải nghiệm phòng Lab, thêm dự án sáng tạo, thêm gắn kết học thuật.'
              : 'More laboratory experiments, more creative projects, stronger academic bonds.'}
          </p>
          <p className="mt-2 text-xs text-[#5F6368] dark:text-[#94A3B8]">
            {lang === 'vi'
              ? 'Mỗi thành viên có thể đăng ký tham gia phân ban phù hợp với nguyên tố năng lực của bản thân ngay từ đầu học kỳ.'
              : 'Every member can apply for the division that best matches their elemental strengths at the start of each semester.'}
          </p>
        </div>

        {/* Region / Semester Marker */}
        <div className="mt-6 flex justify-end items-center gap-2 text-xs text-[#5F6368] dark:text-[#94A3B8]">
          <span
            aria-hidden="true"
            className="inline-flex items-center justify-center w-5 h-3.5 bg-[#DA251D] rounded-[2px] text-[#FFFF00] text-[9px] font-bold leading-none"
          >
            ★
          </span>
          <span>Việt Nam · BWAN Gen 6 (2026–2027)</span>
        </div>

        {/* 3 Google One Tonal Cards */}
        <div className="mt-4 grid grid-cols-1 lg:grid-cols-3 gap-6 items-stretch">
          {CLUB_DEPARTMENTS.map((dept, index) => (
            <article
              key={dept.id}
              className="google-one-tonal-card rounded-[28px] p-7 sm:p-8 flex flex-col justify-between text-center"
            >
              <div>
                {/* Top Dark Callout Pill */}
                <div className="h-8 flex items-center justify-center mb-3">
                  <span className="inline-block bg-[#1F1F2E] dark:bg-[#6C63FF]/30 text-white font-mono text-xs font-semibold px-3.5 py-1 rounded-full">
                    {lang === 'vi' ? 'Nguyên tố đại diện' : 'Element'}:{' '}
                    {dept.elementSymbol} · {dept.atomicNumber}
                  </span>
                </div>

                {/* Department Title */}
                <h3
                  className={`font-display text-2xl sm:text-[25px] font-bold min-h-[64px] flex items-center justify-center leading-snug ${
                    index === 0
                      ? 'text-[#6C63FF] dark:text-[#A39DFF]'
                      : index === 1
                      ? 'text-[#0284C7] dark:text-[#38BDF8]'
                      : 'text-[#D97706] dark:text-[#FBBF24]'
                  }`}
                >
                  {dept.name}
                </h3>

                {/* Subtitle / Code */}
                <div className="mt-4">
                  <p className="font-display text-lg font-bold text-[#1F1F2E] dark:text-white">
                    {index === 0
                      ? lang === 'vi'
                        ? 'Trụ cột Thực nghiệm & Học thuật'
                        : 'Experiments & Academic Pillar'
                      : index === 1
                      ? lang === 'vi'
                        ? 'Trụ cột Thị giác & Dự án số'
                        : 'Visual Design & Digital Pillar'
                      : lang === 'vi'
                      ? 'Trụ cột Sự kiện & Cộng đồng'
                      : 'Events & Community Pillar'}
                  </p>
                  <p className="mt-1 text-xs font-mono text-[#5F6368] dark:text-[#94A3B8]">
                    {dept.code}
                  </p>
                </div>

                {/* Description */}
                <p className="mt-4 text-sm text-[#4A4A68] dark:text-[#CBD5E1] leading-relaxed">
                  {dept.roleDescription}
                </p>

                {/* Primary Google One Capsule Button in #6c63ff */}
                <div className="mt-6">
                  <button
                    type="button"
                    onClick={() => onSelectDivision(dept.name)}
                    className="inline-flex items-center justify-center gap-2 px-6 py-3 rounded-full google-one-chem-btn text-sm font-semibold active:scale-95 cursor-pointer whitespace-nowrap shrink-0"
                  >
                    <span>
                      {lang === 'vi' ? 'Ứng tuyển phân ban' : 'Apply Now'}
                    </span>
                    <ArrowRight className="w-4 h-4" />
                  </button>
                </div>
              </div>

              {/* Bottom Feature Checklist Divider */}
              <div className="mt-8 pt-6 border-t border-[#DFDBD2] dark:border-[#6C63FF]/20 text-left space-y-3">
                {dept.keyActivities.map((act, idx) => (
                  <div
                    key={idx}
                    className="flex items-start gap-2.5 text-xs sm:text-sm text-[#3C4043] dark:text-[#E2E8F0]"
                  >
                    <Check className="w-4 h-4 text-[#6C63FF] dark:text-[#A39DFF] shrink-0 mt-0.5" />
                    <span>{act}</span>
                  </div>
                ))}
              </div>
            </article>
          ))}
        </div>
      </div>
    </section>
  );
};
