export interface ClubProjectItem {
  id: string;
  slug: string;
  code: string;
  title: string;
  category: 'du-an' | 'su-kien' | 'nghien-cuu' | 'ung-dung';
  categoryLabel: string;
  semester: string;
  highlightMetric: string;
  chemicalTheme: string;
  summary: string;
  status: 'ACTIVE' | 'UPCOMING' | 'COMPLETED';
  statusLabel: string;
  previewImage?: string;
}

export const INITIAL_CLUB_PROJECTS: ClubProjectItem[] = [
  {
    id: 'proj-element-personality',
    slug: 'giai-ma-18-nguyen-to-nhan-cach',
    code: 'BWAN-GEN6-01',
    title: '01. Hệ Thống Giải Mã 18 Nguyên Tố Nhân Cách — BWAN Gen 6',
    category: 'ung-dung',
    categoryLabel: 'Ứng Dụng Hóa Học',
    semester: 'Gen 6 · 2026',
    highlightMetric: '1.850+ lượt giải mã',
    chemicalTheme: 'Ne · 10 / Si · 14 / Fe · 26 / Au · 79',
    summary:
      'Trắc nghiệm tương tác phản ánh thói quen, bản năng và nguồn năng lượng tự nhiên qua 5 chiều sâu: tính cách, tư duy, làm việc nhóm, xử lý áp lực và phong cách sáng tạo.',
    status: 'ACTIVE',
    statusLabel: '● ĐANG TRIỂN KHAI',
    previewImage: '/assets/aistudio/image_f5fb4f1c.png',
  },
  {
    id: 'proj-luminescence-night',
    slug: 'dem-hoi-hoa-phat-quang-chemiluminescence',
    code: 'BWAN-EVT-02',
    title: '02. Đêm Hội Hóa Phát Quang — Chemiluminescence Showcase',
    category: 'su-kien',
    categoryLabel: 'Sự Kiện Thường Niên',
    semester: 'Học kỳ I · 2026',
    highlightMetric: '420+ học sinh tham dự',
    chemicalTheme: 'Luminol (C₈H₇N₃O₂) + H₂O₂ → Ánh sáng lam 425 nm',
    summary:
      'Triển lãm thực nghiệm trực quan tái hiện phản ứng oxi hóa Luminol phát quang lạnh trong bóng tối, kết hợp trình diễn tinh thể huỳnh quang và lửa màu kim loại kiềm.',
    status: 'COMPLETED',
    statusLabel: '◆ ĐÃ TỔ CHỨC',
  },
  {
    id: 'proj-green-synthesis',
    slug: 'chiet-xuat-tinh-dau-va-chi-thi-ph-tu-nhien',
    code: 'BWAN-RES-03',
    title: '03. Dự Án Hóa Học Xanh: Chỉ Thị pH Anthocyanin Tự Nhiên',
    category: 'nghien-cuu',
    categoryLabel: 'Nghiên Cứu Khoa Học',
    semester: 'Học kỳ I · 2026',
    highlightMetric: '14 thang màu pH chuẩn',
    chemicalTheme: 'Anthocyanin (Bắp cải tím & Hoa đậu biếc)',
    summary:
      'Nghiên cứu quy trình chiết xuất sắc tố Anthocyanin làm giấy chỉ thị pH thân thiện môi trường, thay thế một phần hóa chất tổng hợp trong các buổi thực hành phổ thông.',
    status: 'ACTIVE',
    statusLabel: '● ĐANG TRIỂN KHAI',
  },
  {
    id: 'proj-crystal-garden',
    slug: 'vuon-tinh-the-silicat-va-phuc-chat',
    code: 'BWAN-PRJ-04',
    title: '04. Triển Lãm Nuôi Tinh Thể Đơn & Vườn Hóa Học Silicat',
    category: 'du-an',
    categoryLabel: 'Dự Án Thực Nghiệm',
    semester: 'Học kỳ II · 2026',
    highlightMetric: '65 mẫu đơn tinh thể',
    chemicalTheme: 'CuSO₄·5H₂O · KAl(SO₄)₂·12H₂O · K₃[Fe(CN)₆]',
    summary:
      'Cuộc thi nuôi đơn tinh thể kích thước lớn giữa các phân ban trong CLB, khảo sát ảnh hưởng của tốc độ bay hơi dung môi và độ bão hòa đến hình thái mạng tinh thể.',
    status: 'UPCOMING',
    statusLabel: '▲ SẮP DIỄN RA',
  },
];

export interface ClubEventItem {
  id: string;
  dateLabel: string;
  title: string;
  location: string;
  category: string;
  formulaTag: string;
  description: string;
  spotsRemaining: number;
}

export const INITIAL_CLUB_EVENTS: ClubEventItem[] = [
  {
    id: 'evt-gen6-recruitment',
    dateLabel: '15 Tháng 11, 2026',
    title: 'Ngày Hội Tuyển Thành Viên & Giải Mã Nguyên Tố BWAN Gen 6',
    location: 'Phòng Lab Hóa Trung Tâm · Tầng 3 Khu A',
    category: 'Sự kiện Trọng tâm',
    formulaTag: 'Fe · 26 / Au · 79',
    description:
      'Khám phá nguyên tố đại diện cho bản thân, trải nghiệm 5 trạm phản ứng hóa học đặc sắc và phỏng vấn gia nhập các ban chuyên môn của CLB.',
    spotsRemaining: 32,
  },
  {
    id: 'evt-workshop-crystal',
    dateLabel: '28 Tháng 11, 2026',
    title: 'Workshop: Nghệ Thuật Nuôi Tinh Thể Đồng Sunfat & Phèn Nhôm',
    location: 'Phòng Thực Hành Vô Cơ · P.304',
    category: 'Workshop Thực nghiệm',
    formulaTag: 'CuSO₄·5H₂O',
    description:
      'Hướng dẫn kỹ thuật pha dung dịch quá bão hòa, chọn mầm tinh thể hoàn hảo và bảo quản đơn tinh thể không bị phong hóa.',
    spotsRemaining: 18,
  },
  {
    id: 'evt-olympic-seminar',
    dateLabel: '12 Tháng 12, 2026',
    title: 'Seminar Học Thuật: Giải Mã Cơ Chế Phản Ứng & Động Hóa Học',
    location: 'Hội Trường Sáng Tạo · Khu B',
    category: 'Giao lưu Học thuật',
    formulaTag: 'ΔG° = -RT lnK',
    description:
      'Chia sẻ kinh nghiệm ôn luyện Học sinh giỏi & Olympic Hóa Học cùng các cựu thành viên BWAN đạt giải Quốc gia.',
    spotsRemaining: 45,
  },
];

export interface ClubDepartment {
  id: string;
  code: string;
  elementSymbol: string;
  atomicNumber: number;
  name: string;
  roleDescription: string;
  keyActivities: string[];
  accentHex: string;
}

export const CLUB_DEPARTMENTS: ClubDepartment[] = [
  {
    id: 'dept-exp',
    code: '01 · BAN CHUYÊN MÔN & THỰC NGHIỆM',
    elementSymbol: 'Pt',
    atomicNumber: 78,
    name: 'Ban Chuyên Môn & Phòng Lab',
    roleDescription:
      'Đóng vai trò chất xúc tác cốt lõi: thiết kế quy trình thí nghiệm biểu diễn, kiểm định an toàn hóa chất và biên soạn cẩm nang học thuật cho toàn CLB.',
    keyActivities: [
      'Thiết kế thí nghiệm Hóa Phát Quang & Tinh thể học',
      'Xây dựng ngân hàng câu hỏi & mô hình phân tử',
      'Đảm bảo an toàn phòng Lab theo tiêu chuẩn GHS',
    ],
    accentHex: '#6C63FF',
  },
  {
    id: 'dept-media',
    code: '02 · BAN TRUYỀN THÔNG & SÁNG TẠO',
    elementSymbol: 'Ne',
    atomicNumber: 10,
    name: 'Ban Truyền Thông & Thiết Kế',
    roleDescription:
      'Tỏa sáng rực rỡ như khí hiếm Neon: chuyển hóa các khái niệm Hóa Học khô khan thành ấn phẩm thị giác, bộ nhận diện sự kiện và dự án tương tác số.',
    keyActivities: [
      'Phát triển giao diện & đồ họa cho dự án 18 Nguyên Tố',
      'Sản xuất chuỗi Infographic Hóa Học Đời Sống',
      'Quay dựng Recap thí nghiệm & quản trị kênh truyền thông',
    ],
    accentHex: '#38BDF8',
  },
  {
    id: 'dept-event',
    code: '03 · BAN TỔ CHỨC SỰ KIỆN & ĐỐI NGOẠI',
    elementSymbol: 'Au',
    atomicNumber: 79,
    name: 'Ban Sự Kiện & Đối Ngoại',
    roleDescription:
      'Bền vững và giá trị như nguyên tố Vàng: kết nối cộng đồng yêu Hóa Học, điều phối hậu cần cho các đêm hội khoa học và hợp tác với các CLB bạn.',
    keyActivities: [
      'Tổ chức Ngày hội Hóa Học mở rộng & Workshop định kỳ',
      'Quản lý tài trợ, hậu cần hóa chất & dụng cụ thủy tinh',
      'Gắn kết các thế hệ thành viên BWAN qua các mùa Gen',
    ],
    accentHex: '#F59E0B',
  },
];

/**
 * Validates and parses a new category/project/event payload to synchronize into the club website
 */
export function parseAndSyncClubProject(
  rawInput: string,
  fallbackTitle?: string,
  fallbackCategory: 'du-an' | 'su-kien' | 'nghien-cuu' | 'ung-dung' = 'du-an'
): { valid: boolean; item?: ClubProjectItem; error?: string } {
  const trimmed = rawInput.trim();
  if (!trimmed && !fallbackTitle?.trim()) {
    return {
      valid: false,
      error: 'Vui lòng nhập tên danh mục/dự án hoặc dán mã JSON để đồng bộ vào website CLB.',
    };
  }

  const categoryLabels: Record<'du-an' | 'su-kien' | 'nghien-cuu' | 'ung-dung', string> = {
    'du-an': 'Dự Án Thực Nghiệm',
    'su-kien': 'Sự Kiện Thường Niên',
    'nghien-cuu': 'Nghiên Cứu Khoa Học',
    'ung-dung': 'Ứng Dụng Hóa Học',
  };

  if (trimmed.startsWith('{')) {
    try {
      const parsed = JSON.parse(trimmed);
      if (!parsed.title || typeof parsed.title !== 'string') {
        return {
          valid: false,
          error: 'Mã JSON thiếu trường bắt buộc "title" (Tên dự án hoặc danh mục).',
        };
      }

      const cat: 'du-an' | 'su-kien' | 'nghien-cuu' | 'ung-dung' = [
        'du-an',
        'su-kien',
        'nghien-cuu',
        'ung-dung',
      ].includes(parsed.category)
        ? parsed.category
        : fallbackCategory;

      const slug = (parsed.slug || parsed.title)
        .toLowerCase()
        .replace(/[^a-z0-9]+/g, '-')
        .replace(/^-|-$/g, '');

      return {
        valid: true,
        item: {
          id: `proj-${Date.now()}`,
          slug,
          code: parsed.code || 'BWAN-SYNC',
          title: parsed.title,
          category: cat,
          categoryLabel: categoryLabels[cat],
          semester: parsed.semester || 'Gen 6 · 2026',
          highlightMetric: parsed.highlightMetric || 'Đã đồng bộ mã nguồn',
          chemicalTheme: parsed.chemicalTheme || 'C₆H₆ · Liên kết cộng hóa trị',
          summary:
            parsed.summary ||
            'Danh mục mới đã được đồng bộ thành công vào kiến trúc nền của Câu lạc bộ Hóa Học.',
          status: 'ACTIVE',
          statusLabel: '● ĐANG TRIỂN KHAI',
        },
      };
    } catch {
      return {
        valid: false,
        error: 'Cú pháp JSON không hợp lệ. Vui lòng kiểm tra lại dấu ngoặc kép hoặc dấu phẩy.',
      };
    }
  }

  const finalTitle = fallbackTitle?.trim() || trimmed.split('\n')[0].slice(0, 70);
  if (finalTitle.length < 3) {
    return {
      valid: false,
      error: 'Tên danh mục hoặc dự án phải có ít nhất 3 ký tự.',
    };
  }

  const slug = finalTitle
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-|-$/g, '');

  return {
    valid: true,
    item: {
      id: `proj-${Date.now()}`,
      slug,
      code: 'BWAN-MOD',
      title: finalTitle,
      category: fallbackCategory,
      categoryLabel: categoryLabels[fallbackCategory],
      semester: 'Gen 6 · 2026',
      highlightMetric: 'Module mở rộng CLB',
      chemicalTheme: 'Fe · 26 / Cu · 29',
      summary:
        trimmed.length > 10
          ? trimmed.slice(0, 200)
          : 'Danh mục hoạt động mới của CLB Hóa Học đã được chuẩn hóa theo tông màu #6c63ff.',
      status: 'ACTIVE',
      statusLabel: '● ĐANG TRIỂN KHAI',
    },
  };
}
