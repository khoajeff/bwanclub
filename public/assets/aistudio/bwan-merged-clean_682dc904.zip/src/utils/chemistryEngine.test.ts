import test from 'node:test';
import assert from 'node:assert/strict';
import {
  INITIAL_CLUB_PROJECTS,
  INITIAL_CLUB_EVENTS,
  CLUB_DEPARTMENTS,
  parseAndSyncClubProject,
} from './chemistryEngine';

test('INITIAL_CLUB_PROJECTS contains BWAN Gen 6 showcase projects and events', () => {
  assert.ok(INITIAL_CLUB_PROJECTS.length >= 4);
  assert.equal(INITIAL_CLUB_PROJECTS[0].code, 'BWAN-GEN6-01');
  assert.equal(INITIAL_CLUB_PROJECTS[0].previewImage, '/assets/aistudio/image_f5fb4f1c.png');
});

test('CLUB_DEPARTMENTS and INITIAL_CLUB_EVENTS are properly structured', () => {
  assert.equal(CLUB_DEPARTMENTS.length, 3);
  assert.ok(INITIAL_CLUB_EVENTS.length >= 3);
});

test('parseAndSyncClubProject validates empty input and parses JSON or text category modules', () => {
  const empty = parseAndSyncClubProject('', '');
  assert.equal(empty.valid, false);
  assert.ok(empty.error);

  const jsonInput = JSON.stringify({
    title: '05. Triển lãm Nhiếp ảnh Vi tinh thể Hóa Học',
    category: 'su-kien',
    code: 'BWAN-EVT-05',
    highlightMetric: '30 tác phẩm kính hiển vi',
    chemicalTheme: 'AgNO₃ + Cu → Tinh thể Bạc',
    summary: 'Ghi lại vẻ đẹp của phản ứng kết tinh bạc dưới kính hiển vi quang học.',
  });

  const parsed = parseAndSyncClubProject(jsonInput);
  assert.equal(parsed.valid, true);
  assert.equal(parsed.item?.title, '05. Triển lãm Nhiếp ảnh Vi tinh thể Hóa Học');
  assert.equal(parsed.item?.category, 'su-kien');
});
