import React, { useState, useEffect, useRef } from 'react';
import {
  BankTransferConfig,
  DonationSubmissionPayload,
  DonorRecord,
  QrCodeRequestParams,
} from '../types';
import {
  formatVnd,
  validateDonationPayload,
  generateTransferSyntax,
  buildAppsScriptCreateUrl,
} from '../donationLogic';
import {
  QrCode,
  CheckCircle2,
  ShieldCheck,
  Sparkles,
  Loader2,
  ExternalLink,
  AlertCircle,
  ArrowRight,
  Clock,
  RefreshCw,
} from 'lucide-react';

interface QuickDonatePanelProps {
  campaignCode: string;
  campaignTitle: string;
  presetAmounts: number[];
  bankConfig: BankTransferConfig;
  /**
   * Chỉ được gọi KHI VÀ CHỈ KHI cổng PayOS xác nhận trạng thái thanh toán là PAID.
   */
  onDonationVerified: (
    payload: DonationSubmissionPayload,
    orderMeta?: { paymentLinkId?: string; orderCode?: string | number }
  ) => DonorRecord;
  resolveCustomQrUrl?: (params: QrCodeRequestParams) => string | null;
}

interface PendingOrderState {
  paymentLinkId: string;
  orderCode?: string | number;
  checkoutUrl: string;
  payload: DonationSubmissionPayload;
  receiptCode: string;
  status: 'PENDING' | 'PAID' | 'CANCELLED' | 'EXPIRED';
}

export const QuickDonatePanel: React.FC<QuickDonatePanelProps> = ({
  campaignCode,
  campaignTitle,
  bankConfig,
  onDonationVerified,
}) => {
  const [amountInput, setAmountInput] = useState<string>('50000');
  const [donorName, setDonorName] = useState<string>('');
  const [affiliation, setAffiliation] = useState<string>('');
  const [message, setMessage] = useState<string>('');
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [apiError, setApiError] = useState<string | null>(null);
  const [isCreatingQr, setIsCreatingQr] = useState<boolean>(false);
  const [isCheckingStatus, setIsCheckingStatus] = useState<boolean>(false);
  const [pendingOrder, setPendingOrder] = useState<PendingOrderState | null>(null);
  const [verifiedRecord, setVerifiedRecord] = useState<DonorRecord | null>(null);

  const confirmedPaymentIdsRef = useRef<Set<string>>(new Set());

  const parsedAmount = Number(amountInput.replace(/[^0-9]/g, ''));
  const amountVnd = Number.isFinite(parsedAmount) ? parsedAmount : 0;

  const { receiptCode } = generateTransferSyntax(
    bankConfig.transferPrefix,
    campaignCode,
    donorName || 'BWAN',
    amountVnd
  );

  // Hàm kiểm tra trạng thái thực tế của mã QR trên PayOS (PENDING vs PAID)
  const checkOrderPaymentStatus = async (order: PendingOrderState) => {
    if (!order.paymentLinkId || order.status !== 'PENDING') return;
    if (confirmedPaymentIdsRef.current.has(order.paymentLinkId)) return;

    try {
      setIsCheckingStatus(true);
      const res = await fetch(`/api/payos-status/${order.paymentLinkId}`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          donorName: order.payload.donorName,
          affiliation: order.payload.affiliation,
          amountVnd: order.payload.amountVnd,
          message: order.payload.message,
          receiptCode: order.receiptCode,
          orderCode: order.orderCode,
        }),
      });

      if (!res.ok) return;

      const data = (await res.json()) as {
        status?: string;
        verifiedRecord?: DonorRecord;
      };

      if (data.status === 'PAID') {
        if (!confirmedPaymentIdsRef.current.has(order.paymentLinkId)) {
          confirmedPaymentIdsRef.current.add(order.paymentLinkId);
          setPendingOrder((prev) =>
            prev ? { ...prev, status: 'PAID' } : null
          );
          const created = onDonationVerified(order.payload, {
            paymentLinkId: order.paymentLinkId,
            orderCode: order.orderCode,
          });
          setVerifiedRecord(created);
        }
      } else if (data.status === 'CANCELLED' || data.status === 'EXPIRED') {
        setPendingOrder((prev) =>
          prev
            ? { ...prev, status: data.status as 'CANCELLED' | 'EXPIRED' }
            : null
        );
      }
    } catch {
      // Giữ trạng thái chờ để chu kỳ tiếp theo kiểm tra lại
    } finally {
      setIsCheckingStatus(false);
    }
  };

  // Tự động kiểm tra trạng thái thanh toán mỗi 2.5 giây khi đang có đơn PENDING
  useEffect(() => {
    if (!pendingOrder || pendingOrder.status !== 'PENDING') return;

    const timer = window.setInterval(() => {
      checkOrderPaymentStatus(pendingOrder);
    }, 2500);

    return () => window.clearInterval(timer);
  }, [pendingOrder]);

  const handleAmountChange = (rawVal: string) => {
    const digitsOnly = rawVal.replace(/[^0-9]/g, '');
    setAmountInput(digitsOnly);
    setApiError(null);
    if (errors.amountVnd) {
      setErrors((prev) => {
        const next = { ...prev };
        delete next.amountVnd;
        return next;
      });
    }
  };

  const handleQuickChipSelect = (val: number) => {
    setAmountInput(String(val));
    setApiError(null);
    if (errors.amountVnd) {
      setErrors((prev) => {
        const next = { ...prev };
        delete next.amountVnd;
        return next;
      });
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setApiError(null);

    const payload: DonationSubmissionPayload = {
      donorName: donorName.trim(),
      affiliation: affiliation.trim() || 'Thành viên & Người yêu Hóa học BWAN',
      amountVnd,
      message: message.trim(),
      isAnonymous: false,
    };

    const validation = validateDonationPayload(payload);
    if (!validation.valid) {
      setErrors(validation.errors);
      return;
    }

    setErrors({});
    setIsCreatingQr(true);
    setPendingOrder(null);
    setVerifiedRecord(null);

    const requestUrl = buildAppsScriptCreateUrl(amountVnd, payload.donorName);

    try {
      const response = await fetch(requestUrl, {
        method: 'GET',
        headers: {
          Accept: 'application/json',
        },
      });

      if (!response.ok) {
        throw new Error(`Máy chủ trả về mã trạng thái ${response.status}`);
      }

      const json = await response.json();
      const targetCheckoutUrl: string | undefined =
        json?.data?.checkoutUrl || json?.checkoutUrl;

      if (!targetCheckoutUrl) {
        throw new Error('Phản hồi từ hệ thống không chứa đường dẫn data.checkoutUrl.');
      }

      // Trích xuất paymentLinkId để kiểm tra trạng thái thanh toán thực tế (PENDING vs PAID)
      const extractedLinkId: string =
        json?.data?.paymentLinkId ||
        targetCheckoutUrl.split('/web/')[1]?.split(/[/?#]/)[0] ||
        '';
      const orderCode = json?.data?.orderCode;

      const newPendingOrder: PendingOrderState = {
        paymentLinkId: extractedLinkId,
        orderCode,
        checkoutUrl: targetCheckoutUrl,
        payload,
        receiptCode: orderCode ? `ORD-${orderCode}` : receiptCode,
        status: 'PENDING',
      };

      // Lưu trạng thái ĐANG CHỜ THANH TOÁN (chưa đưa lên Bảng xếp hạng khi chưa quét QR trả tiền!)
      setPendingOrder(newPendingOrder);

      // Tự động mở trang quét mã QR thanh toán trong tab mới
      const anchor = document.createElement('a');
      anchor.href = targetCheckoutUrl;
      anchor.target = '_blank';
      anchor.rel = 'noopener noreferrer';
      document.body.appendChild(anchor);
      anchor.click();
      document.body.removeChild(anchor);
    } catch (err) {
      const msg =
        err instanceof Error
          ? err.message
          : 'Không thể kết nối tới cổng tạo mã QR. Vui lòng thử lại.';
      setApiError(msg);
    } finally {
      setIsCreatingQr(false);
    }
  };

  const formattedDisplayInput = amountInput
    ? amountVnd.toString().replace(/\B(?=(\d{3})+(?!\d))/g, '.')
    : '';

  const quickSuggestions = [2_000, 20_000, 50_000, 100_000, 200_000, 500_000];

  return (
    <div
      id="quick-donate-panel"
      className="scroll-mt-24 rounded-3xl border border-slate-200/90 bg-white p-6 sm:p-8 shadow-xl shadow-slate-200/50"
    >
      {/* Header Khu vực Quyên góp */}
      <div className="border-b border-slate-100 pb-5">
        <div className="flex items-center justify-between text-xs font-semibold text-[#5D50FE]">
          <span>Cổng Quyên Góp Trực Tuyến · BWAN Chemistry</span>
          <span className="font-mono-tabular text-slate-400">
            MÃ QUỸ: {campaignCode}
          </span>
        </div>
        <h3 className="mt-1.5 text-2xl font-extrabold tracking-tight text-[#181826]">
          Quyên Góp Ủng Hộ CLB BWAN
        </h3>
        <p className="mt-1.5 text-xs leading-relaxed text-[#525866] sm:text-sm">
          Cảm ơn bạn đã dành thời gian để đọc trang web này. Mọi số tiền câu lạc bộ nhận được đều là nguồn động lực to lớn để chúng mình có thể phát triển hơn nữa và lan tỏa ngọn lửa đam mê Hóa học đến cộng đồng!
        </p>
      </div>

      <form onSubmit={handleSubmit} className="mt-6 space-y-5" noValidate>
        {/* 1. Ô nhập Tên người ủng hộ (name) */}
        <div>
          <label
            htmlFor="donate-patron-name"
            className="block text-xs font-bold text-[#181826]"
          >
            1. Tên người ủng hộ <span className="text-[#5D50FE]">*</span>
          </label>
          <input
            id="donate-patron-name"
            name="name"
            type="text"
            value={donorName}
            onChange={(e) => {
              setDonorName(e.target.value);
              if (errors.donorName) {
                setErrors((prev) => {
                  const next = { ...prev };
                  delete next.donorName;
                  return next;
                });
              }
            }}
            placeholder="Nhập tên của bạn để vinh danh lên Bảng xếp hạng"
            disabled={isCreatingQr}
            className="mt-2 w-full rounded-2xl border border-slate-200 bg-[#F8F8FB] px-4 py-3 text-sm font-medium text-[#181826] placeholder-slate-400 transition-colors focus:border-[#5D50FE] focus:bg-white focus:outline-none disabled:opacity-60"
          />
          {errors.donorName && (
            <p role="alert" className="mt-1.5 text-xs font-semibold text-rose-600">
              {errors.donorName}
            </p>
          )}
        </div>

        {/* 2. Ô nhập Số tiền muốn ủng hộ (amount - tối thiểu 2000 VNĐ) */}
        <div>
          <div className="flex items-center justify-between">
            <label
              htmlFor="donate-custom-amount"
              className="text-xs font-bold text-[#181826]"
            >
              2. Số tiền muốn ủng hộ (tối thiểu 2.000 VNĐ){' '}
              <span className="text-[#5D50FE]">*</span>
            </label>
            <span className="font-mono-tabular text-xs font-bold text-[#5D50FE]">
              {amountVnd >= 2_000 ? formatVnd(amountVnd) : 'Tối thiểu 2.000 ₫'}
            </span>
          </div>

          <div className="relative mt-2 flex items-center rounded-2xl border-2 border-[#5D50FE]/40 bg-[#F8F8FB] transition-colors focus-within:border-[#5D50FE] focus-within:bg-white">
            <input
              id="donate-custom-amount"
              name="amount"
              type="text"
              inputMode="numeric"
              value={formattedDisplayInput}
              onChange={(e) => handleAmountChange(e.target.value)}
              placeholder="Nhập số tiền (tối thiểu 2.000)"
              aria-label="Số tiền muốn ủng hộ (tối thiểu 2000 VNĐ)"
              disabled={isCreatingQr}
              className="w-full bg-transparent py-3.5 pl-4 pr-16 font-mono-tabular text-xl font-extrabold text-[#181826] placeholder-slate-400 focus:outline-none disabled:opacity-60"
            />
            <span className="pointer-events-none absolute right-4 font-mono-tabular text-xs font-bold text-[#5D50FE]">
              VNĐ
            </span>
          </div>

          {/* Gợi ý chọn nhanh số tiền */}
          <div className="mt-2.5 flex flex-wrap items-center gap-1.5">
            <span className="mr-1 text-[11px] font-medium text-[#525866]">
              Chọn nhanh:
            </span>
            {quickSuggestions.map((amt) => {
              const isSelected = amountVnd === amt;
              return (
                <button
                  key={amt}
                  type="button"
                  disabled={isCreatingQr}
                  onClick={() => handleQuickChipSelect(amt)}
                  className={`rounded-full px-3 py-1 font-mono-tabular text-xs font-bold transition-all cursor-pointer whitespace-nowrap disabled:opacity-50 ${
                    isSelected
                      ? 'bg-[#5D50FE] text-white shadow-xs shadow-[#5D50FE]/25'
                      : 'border border-slate-200 bg-white text-[#525866] hover:border-[#5D50FE] hover:text-[#5D50FE]'
                  }`}
                >
                  {formatVnd(amt)}
                </button>
              );
            })}
          </div>

          {errors.amountVnd && (
            <p role="alert" className="mt-1.5 text-xs font-semibold text-rose-600">
              {errors.amountVnd}
            </p>
          )}
        </div>

        {/* Phân ban / Đơn vị & Lời nhắn tùy chọn */}
        <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
          <div>
            <label
              htmlFor="donate-affiliation"
              className="block text-xs font-semibold text-[#525866]"
            >
              Phân ban / Khóa (Tùy chọn)
            </label>
            <input
              id="donate-affiliation"
              type="text"
              value={affiliation}
              onChange={(e) => setAffiliation(e.target.value)}
              placeholder="VD: Phân ban Thực nghiệm"
              disabled={isCreatingQr}
              className="mt-1.5 w-full rounded-xl border border-slate-200 bg-[#F8F8FB] px-3.5 py-2.5 text-xs text-[#181826] placeholder-slate-400 focus:border-[#5D50FE] focus:bg-white focus:outline-none disabled:opacity-60"
            />
          </div>

          <div>
            <label
              htmlFor="donate-message"
              className="block text-xs font-semibold text-[#525866]"
            >
              Lời nhắn gửi CLB (Tùy chọn)
            </label>
            <input
              id="donate-message"
              type="text"
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              placeholder="Nhập lời chúc gửi tới CLB (nếu có)"
              disabled={isCreatingQr}
              className="mt-1.5 w-full rounded-xl border border-slate-200 bg-[#F8F8FB] px-3.5 py-2.5 text-xs text-[#181826] placeholder-slate-400 focus:border-[#5D50FE] focus:bg-white focus:outline-none disabled:opacity-60"
            />
          </div>
        </div>

        {/* 3. Nút bấm "Tạo mã QR Ủng hộ" */}
        <button
          type="submit"
          disabled={isCreatingQr}
          className="flex w-full items-center justify-center gap-2.5 rounded-full bg-[#5D50FE] px-6 py-4 text-sm font-bold text-white shadow-md shadow-[#5D50FE]/25 transition-all hover:bg-[#4B3FE8] disabled:cursor-wait disabled:opacity-80 cursor-pointer whitespace-nowrap"
        >
          {isCreatingQr ? (
            <>
              <Loader2 className="h-4 w-4 animate-spin" />
              <span>Đang tạo mã QR...</span>
            </>
          ) : (
            <>
              <QrCode className="h-4 w-4" />
              <span>Tạo mã QR Ủng hộ</span>
              <ArrowRight className="h-4 w-4" />
            </>
          )}
        </button>

        {/* Thông báo lỗi kết nối nếu có */}
        {apiError && (
          <div
            role="alert"
            className="flex items-start gap-2.5 rounded-2xl border border-rose-200 bg-rose-50 p-3.5 text-xs text-rose-900"
          >
            <AlertCircle className="mt-0.5 h-4 w-4 shrink-0 text-rose-600" />
            <div>
              <p className="font-bold">Không thể tạo mã QR thanh toán</p>
              <p className="mt-0.5 text-rose-800/90">{apiError}</p>
            </div>
          </div>
        )}

        {/* Trạng thái 1: ĐANG CHỜ QUÉT MÃ QR THANH TOÁN (PENDING — Chưa đưa lên Bảng xếp hạng!) */}
        {pendingOrder && pendingOrder.status === 'PENDING' && !isCreatingQr && (
          <div
            role="status"
            data-testid="donation-pending-payment"
            className="space-y-3 rounded-2xl border border-indigo-200 bg-indigo-50/70 p-4 text-xs text-slate-800"
          >
            <div className="flex items-center justify-between gap-2">
              <div className="flex items-center gap-2 font-bold text-[#5D50FE]">
                <Clock className="h-4 w-4 shrink-0 animate-spin" />
                <span>
                  Đang chờ {pendingOrder.payload.donorName} quét mã QR thanh toán (
                  {formatVnd(pendingOrder.payload.amountVnd)})
                </span>
              </div>
              <span className="font-mono-tabular text-[11px] font-semibold text-amber-700">
                CHỜ THANH TOÁN
              </span>
            </div>

            <p className="leading-relaxed text-slate-600">
              Hệ thống chỉ ghi nhận lên <strong>Bảng xếp hạng Top Donate</strong> và cộng vào <strong>Tổng quỹ</strong> sau khi bạn quét mã QR chuyển khoản thành công trên trang PayOS.
            </p>

            <div className="flex flex-wrap items-center gap-2.5 pt-1">
              <a
                href={pendingOrder.checkoutUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-2 rounded-full bg-[#5D50FE] px-4 py-2 text-xs font-bold text-white shadow-xs transition-colors hover:bg-[#4B3FE8]"
              >
                <span>Mở Trang Quét Mã QR Thanh Toán</span>
                <ExternalLink className="h-3.5 w-3.5" />
              </a>

              <button
                type="button"
                disabled={isCheckingStatus}
                onClick={() => checkOrderPaymentStatus(pendingOrder)}
                className="inline-flex items-center gap-1.5 rounded-full border border-slate-300 bg-white px-3.5 py-2 text-xs font-semibold text-slate-700 hover:border-[#5D50FE] hover:text-[#5D50FE] cursor-pointer"
              >
                <RefreshCw
                  className={`h-3.5 w-3.5 ${isCheckingStatus ? 'animate-spin' : ''}`}
                />
                <span>Kiểm tra trạng thái thanh toán</span>
              </button>
            </div>
          </div>
        )}

        {/* Trạng thái 2: ĐÃ THANH TOÁN THÀNH CÔNG (PAID — Đã đưa lên Bảng xếp hạng!) */}
        {pendingOrder && pendingOrder.status === 'PAID' && verifiedRecord && (
          <div
            role="status"
            data-testid="donation-realtime-success"
            className="space-y-2 rounded-2xl border border-emerald-200 bg-emerald-50/80 p-4 text-xs text-slate-800"
          >
            <div className="flex items-center gap-2 font-bold text-emerald-700">
              <CheckCircle2 className="h-4 w-4 shrink-0 text-emerald-600" />
              <span>
                Thanh toán thành công! Đã vinh danh {verifiedRecord.name} (
                {formatVnd(verifiedRecord.amountVnd)}) lên Bảng xếp hạng!
              </span>
            </div>
            <p className="text-slate-600">
              Cảm ơn bạn đã đồng hành cùng CLB Hóa học BWAN. Mã biên lai xác thực:{' '}
              <strong className="font-mono-tabular">
                {verifiedRecord.verifiedReceiptCode}
              </strong>
            </p>
          </div>
        )}

        {/* Trạng thái 3: ĐÃ HỦY HOẶC HẾT HẠN */}
        {pendingOrder &&
          (pendingOrder.status === 'CANCELLED' ||
            pendingOrder.status === 'EXPIRED') && (
            <div
              role="alert"
              className="rounded-2xl border border-amber-200 bg-amber-50 p-4 text-xs text-amber-900"
            >
              <p className="font-bold">
                Giao dịch mã QR đã bị hủy hoặc hết hạn thanh toán.
              </p>
              <p className="mt-0.5 text-amber-800">
                Khoản quyên góp chưa được ghi nhận lên Bảng xếp hạng. Bạn có thể bấm &ldquo;Tạo mã QR Ủng hộ&rdquo; để tạo mã mới.
              </p>
            </div>
          )}

        <div className="flex items-center justify-between border-t border-slate-100 pt-3 text-[11px] text-slate-400">
          <span className="inline-flex items-center gap-1.5">
            <ShieldCheck className="h-3.5 w-3.5 text-[#5D50FE]" />
            <span>Xác thực thanh toán tự động qua PayOS</span>
          </span>
          <span className="inline-flex items-center gap-1 font-mono-tabular text-[#5D50FE]">
            <Sparkles className="h-3 w-3" />
            <span>Cập nhật khi đã thanh toán</span>
          </span>
        </div>
      </form>
    </div>
  );
};
