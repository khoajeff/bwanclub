import React, { useState, useEffect } from 'react';
import { DonorRecord } from '../types';
import {
  rankDonors,
  formatVnd,
  formatDonationTimestamp,
} from '../donationLogic';
import {
  Crown,
  Medal,
  Award,
  ChevronDown,
  ChevronUp,
  Search,
  MessageSquareHeart,
  Sparkles,
  Clock,
  RefreshCw,
} from 'lucide-react';

interface TopDonorsSectionProps {
  donors: DonorRecord[];
  latestDonorName?: string | null;
  isLoadingLeaderboard?: boolean;
  onRefreshLeaderboard?: () => void;
  onScrollToDonate: () => void;
}

export const TopDonorsSection: React.FC<TopDonorsSectionProps> = ({
  donors,
  latestDonorName,
  isLoadingLeaderboard = false,
  onRefreshLeaderboard,
  onScrollToDonate,
}) => {
  const [activeTab, setActiveTab] = useState<'ranking' | 'recent'>('ranking');
  const [showAllRanks, setShowAllRanks] = useState<boolean>(false);
  const [searchQuery, setSearchQuery] = useState<string>('');

  const allRanked = rankDonors(donors);

  // Nếu người dùng vừa thanh toán thành công và nằm ở hạng >= 4, tự động mở danh sách Top dưới
  useEffect(() => {
    if (!latestDonorName) return;
    const found = allRanked.find(
      (item) =>
        item.donorName.toLowerCase() === latestDonorName.trim().toLowerCase()
    );
    if (found && found.rank > 3) {
      setShowAllRanks(true);
    }
  }, [latestDonorName, allRanked.length]);

  const top1 = allRanked[0] || null;
  const top2 = allRanked[1] || null;
  const top3 = allRanked[2] || null;

  const lowerRanks = allRanked.slice(3).filter((item) => {
    if (!searchQuery.trim()) return true;
    const q = searchQuery.toLowerCase();
    return (
      item.donorName.toLowerCase().includes(q) ||
      item.affiliation.toLowerCase().includes(q) ||
      item.latestReceiptCode.toLowerCase().includes(q)
    );
  });

  const donorMessages = donors.filter(
    (d) => d.message && d.message.trim().length > 0
  );

  const isHighlightedDonor = (name?: string) =>
    Boolean(
      name &&
        latestDonorName &&
        name.trim().toLowerCase() === latestDonorName.trim().toLowerCase()
    );

  return (
    <>
      {/* BẢNG XẾP HẠNG TOP DONATE (PODIUM VÀNG - BẠC - ĐỒNG & TAB LƯỢT ỦNG HỘ MỚI NHẤT) */}
      <section
        id="leaderboard-section"
        className="scroll-mt-24 py-14 sm:py-16"
      >
        {/* Tiêu đề khu vực */}
        <div className="mx-auto max-w-3xl text-center">
          <div className="inline-flex items-center gap-2 text-xs font-semibold text-[#5D50FE]">
            <Crown className="h-4 w-4 text-amber-500" />
            <span>Bảng Vinh Danh Thực Tế Thời Gian Thực</span>
            <span aria-hidden="true">·</span>
            <span>BWAN Chemistry</span>
          </div>
          <h2
            style={{ textWrap: 'balance' }}
            className="mt-2.5 text-3xl font-extrabold tracking-tight text-[#181826] sm:text-4xl"
          >
            Bảng Xếp Hạng{' '}
            <span className="bg-gradient-to-r from-[#6c63ff] via-[#4F75FF] to-[#0EA5E9] bg-clip-text text-transparent">
              Top Donate CLB BWAN
            </span>
          </h2>
          <p className="mt-3 text-sm leading-relaxed text-[#525866] sm:text-base">
            Tự động đồng bộ dữ liệu thực tế từ hệ thống CLB và cộng dồn số tiền của những người trùng tên để xếp hạng từ cao xuống thấp.
          </p>

          {/* Thanh chuyển đổi Tab: Xếp hạng Top Donate (Cộng dồn) & Lượt ủng hộ mới nhất (Thời gian thực) */}
          <div className="mt-6 flex flex-wrap items-center justify-center gap-3">
            <div
              role="tablist"
              aria-label="Chế độ xem bảng xếp hạng"
              className="inline-flex items-center rounded-full border border-slate-200/90 bg-white p-1.5 shadow-xs"
            >
              <button
                type="button"
                role="tab"
                aria-selected={activeTab === 'ranking'}
                onClick={() => setActiveTab('ranking')}
                className={`inline-flex items-center gap-2 rounded-full px-5 py-2 text-xs font-bold transition-all cursor-pointer whitespace-nowrap ${
                  activeTab === 'ranking'
                    ? 'bg-[#5D50FE] text-white shadow-xs'
                    : 'text-[#525866] hover:text-[#5D50FE]'
                }`}
              >
                <Crown className="h-3.5 w-3.5" />
                <span>Top Donate Cộng Dồn ({allRanked.length})</span>
              </button>

              <button
                type="button"
                role="tab"
                aria-selected={activeTab === 'recent'}
                onClick={() => setActiveTab('recent')}
                className={`inline-flex items-center gap-2 rounded-full px-5 py-2 text-xs font-bold transition-all cursor-pointer whitespace-nowrap ${
                  activeTab === 'recent'
                    ? 'bg-[#5D50FE] text-white shadow-xs'
                    : 'text-[#525866] hover:text-[#5D50FE]'
                }`}
              >
                <Clock className="h-3.5 w-3.5" />
                <span>Lượt Ủng Hộ Mới Nhất ({donors.length})</span>
              </button>
            </div>

            {onRefreshLeaderboard && (
              <button
                type="button"
                onClick={onRefreshLeaderboard}
                disabled={isLoadingLeaderboard}
                className="inline-flex items-center gap-1.5 rounded-full border border-slate-200 bg-white px-4 py-2.5 text-xs font-semibold text-[#525866] shadow-xs transition-colors hover:border-[#5D50FE] hover:text-[#5D50FE] disabled:opacity-60 cursor-pointer whitespace-nowrap"
              >
                <RefreshCw
                  className={`h-3.5 w-3.5 text-[#5D50FE] ${
                    isLoadingLeaderboard ? 'animate-spin' : ''
                  }`}
                />
                <span>
                  {isLoadingLeaderboard ? 'Đang tải...' : 'Cập nhật dữ liệu'}
                </span>
              </button>
            )}
          </div>
        </div>

        {activeTab === 'recent' ? (
          /* TAB HIỂN THỊ CÁC LƯỢT ỦNG HỘ MỚI NHẤT THEO THỜI GIAN THỰC */
          <div
            data-testid="leaderboard-recent-tab-panel"
            className="mx-auto mt-10 max-w-4xl overflow-hidden rounded-3xl border border-slate-200/90 bg-white shadow-sm"
          >
            <div className="flex flex-col justify-between gap-2 border-b border-slate-100 px-6 py-5 sm:flex-row sm:items-center">
              <div>
                <h3 className="text-base font-extrabold text-[#181826]">
                  Nhật Ký Các Lượt Ủng Hộ Mới Nhất Theo Thời Gian Thực
                </h3>
                <p className="mt-0.5 text-xs text-[#525866]">
                  Hiển thị chi tiết từng giao dịch ủng hộ mới nhất từ cổng thanh toán QR của CLB BWAN
                </p>
              </div>
              <span className="font-mono-tabular text-xs font-bold text-[#5D50FE]">
                Tổng cộng: {donors.length} lượt ủng hộ
              </span>
            </div>

            {donors.length === 0 ? (
              <div className="px-6 py-12 text-center text-sm text-[#525866]">
                {isLoadingLeaderboard
                  ? 'Đang tải danh sách lượt ủng hộ mới nhất...'
                  : 'Chưa có lượt ủng hộ nào được ghi nhận.'}
              </div>
            ) : (
              <div className="divide-y divide-slate-100">
                {donors.map((item, idx) => (
                  <div
                    key={item.id || `${item.name}_${item.timestampIso}_${idx}`}
                    className="flex flex-col justify-between gap-2 px-6 py-4 transition-colors hover:bg-slate-50/80 sm:flex-row sm:items-center"
                  >
                    <div className="flex items-center gap-3.5">
                      <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-xl bg-[#5D50FE]/10 font-mono-tabular text-xs font-extrabold text-[#5D50FE]">
                        #{idx + 1}
                      </span>
                      <div>
                        <p className="text-sm font-bold text-[#181826]">
                          {item.name}
                        </p>
                        <p className="mt-0.5 font-mono-tabular text-xs text-[#525866]">
                          Thời gian: {formatDonationTimestamp(item.timestampIso)}
                        </p>
                      </div>
                    </div>

                    <div className="flex items-center justify-between gap-4 pl-12 sm:justify-end sm:pl-0">
                      <span className="font-mono-tabular text-base font-extrabold text-[#5D50FE]">
                        +{formatVnd(item.amountVnd)}
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        ) : (
          <>
            {/* TOP 1 - 2 - 3 PODIUM: VÀNG (VƯƠNG MIỆN) · BẠC · ĐỒNG */}
            <div className="mt-12 grid grid-cols-1 items-end gap-6 lg:grid-cols-3 lg:gap-7">
              {/* TOP 2: KHUNG BẠC (SILVER) */}
              <article
                data-testid="leaderboard-top-2"
            className={`relative flex flex-col justify-between rounded-3xl border-2 border-slate-300 bg-gradient-to-b from-slate-100/95 via-white to-white p-6 sm:p-7 shadow-lg shadow-slate-300/40 transition-transform duration-200 lg:order-1 ${
              isHighlightedDonor(top2?.donorName)
                ? 'ring-4 ring-[#6c63ff]/30'
                : ''
            }`}
          >
            <div>
              <div className="flex items-center justify-between gap-3">
                <div className="inline-flex items-center gap-2">
                  <span className="flex h-9 w-9 items-center justify-center rounded-full border border-slate-300 bg-gradient-to-br from-slate-100 to-slate-300 text-slate-700 shadow-xs">
                    <Medal className="h-4 w-4 text-slate-700" />
                  </span>
                  <div>
                    <span className="block text-xs font-extrabold tracking-wider text-slate-600">
                      TOP 2 · HẠNG BẠC
                    </span>
                    <span className="text-[11px] text-slate-500">
                      Á quân ủng hộ CLB
                    </span>
                  </div>
                </div>

                <span className="font-mono-tabular text-2xl font-black text-slate-400">
                  #02
                </span>
              </div>

              <div className="mt-5 border-t border-slate-200/80 pt-5">
                {top2 ? (
                  <>
                    <div className="flex items-center gap-2">
                      <h3 className="text-xl font-extrabold text-[#181826]">
                        {top2.donorName}
                      </h3>
                      {isHighlightedDonor(top2.donorName) && (
                        <span className="text-xs font-bold text-[#5D50FE]">
                          · Mới cập nhật
                        </span>
                      )}
                    </div>
                    <p className="mt-1 text-xs font-medium text-[#525866]">
                      {top2.affiliation}
                    </p>
                  </>
                ) : (
                  <>
                    <h3 className="text-lg font-bold text-slate-400">
                      Đang chờ nhà hảo tâm Top 2
                    </h3>
                    <p className="mt-1 text-xs text-slate-400">
                      Vị trí Á quân Hạng Bạc đang rộng mở
                    </p>
                  </>
                )}
              </div>

              <div className="mt-5 rounded-2xl border border-slate-200 bg-slate-50/90 px-4 py-3.5">
                <span className="block text-[11px] font-semibold text-slate-500">
                  Tổng số tiền đã ủng hộ
                </span>
                <span className="mt-0.5 block font-mono-tabular text-2xl font-extrabold text-slate-800">
                  {top2 ? formatVnd(top2.totalAmountVnd) : '0 ₫'}
                </span>
              </div>

              {top2?.latestMessage && (
                <p className="mt-4 line-clamp-2 text-xs italic leading-relaxed text-[#525866]">
                  “{top2.latestMessage}”
                </p>
              )}
            </div>

            <div className="mt-5 flex items-center justify-between border-t border-slate-100 pt-3.5 text-[11px] text-slate-500">
              <span>
                {top2
                  ? `Số lượt ủng hộ: ${top2.donationsCount} lần`
                  : 'Chưa có giao dịch'}
              </span>
              <span className="font-mono-tabular font-medium text-slate-600">
                {top2 ? top2.latestReceiptCode : '—'}
              </span>
            </div>
          </article>

          {/* TOP 1: KHUNG VÀNG & VƯƠNG MIỆN (GOLD CROWN CHAMPION) */}
          <article
            data-testid="leaderboard-top-1"
            className={`relative flex flex-col justify-between rounded-3xl border-2 border-amber-400 bg-gradient-to-b from-amber-50/95 via-white to-white p-7 sm:p-8 shadow-xl shadow-amber-500/15 transition-transform duration-200 lg:order-2 lg:-translate-y-4 ${
              isHighlightedDonor(top1?.donorName)
                ? 'ring-4 ring-amber-400/50'
                : ''
            }`}
          >
            {/* Biểu tượng Vương Miện Vàng nổi bật trên đỉnh khung */}
            <div className="-mt-11 mb-3 flex justify-center">
              <div className="inline-flex items-center gap-2 rounded-full border-2 border-amber-400 bg-gradient-to-r from-amber-400 via-yellow-400 to-amber-500 px-4 py-1.5 text-xs font-extrabold text-slate-950 shadow-md shadow-amber-500/25">
                <Crown className="h-4 w-4 fill-slate-950 text-slate-950" />
                <span>TOP 1 · VƯƠNG MIỆN VÀNG</span>
              </div>
            </div>

            <div>
              <div className="flex items-center justify-between gap-3">
                <div className="inline-flex items-center gap-3">
                  <span className="flex h-12 w-12 shrink-0 items-center justify-center rounded-2xl border-2 border-amber-400 bg-gradient-to-br from-amber-100 via-yellow-200 to-amber-300 text-amber-800 shadow-sm">
                    <Crown className="h-6 w-6 fill-amber-600 text-amber-700" />
                  </span>
                  <div>
                    <span className="block text-xs font-extrabold tracking-wider text-amber-700">
                      QUÁN QUÂN DONATE
                    </span>
                    <span className="text-xs text-amber-800/80">
                      Người ủng hộ cao nhất CLB
                    </span>
                  </div>
                </div>

                <span className="font-mono-tabular text-3xl font-black text-amber-500">
                  #01
                </span>
              </div>

              <div className="mt-5 border-t border-amber-200/80 pt-5">
                {top1 ? (
                  <>
                    <div className="flex flex-wrap items-center gap-2">
                      <h3 className="text-2xl font-extrabold text-[#181826]">
                        {top1.donorName}
                      </h3>
                      {isHighlightedDonor(top1.donorName) && (
                        <span className="inline-flex items-center gap-1 text-xs font-bold text-amber-700">
                          <Sparkles className="h-3.5 w-3.5" />
                          <span>Vừa lên Top 1!</span>
                        </span>
                      )}
                    </div>
                    <p className="mt-1 text-xs font-medium text-[#525866]">
                      {top1.affiliation}
                    </p>
                  </>
                ) : (
                  <>
                    <h3 className="text-xl font-extrabold text-[#181826]">
                      Đang chờ Quán Quân đầu tiên
                    </h3>
                    <p className="mt-1 text-xs text-[#525866]">
                      Hãy là người đầu tiên quét mã QR ủng hộ để giữ Vương Miện Vàng!
                    </p>
                  </>
                )}
              </div>

              <div className="mt-5 rounded-2xl border-2 border-amber-300/90 bg-gradient-to-r from-amber-50 via-yellow-50/70 to-amber-50 px-5 py-4">
                <span className="block text-xs font-bold text-amber-800">
                  Tổng số tiền ủng hộ cao nhất
                </span>
                <span className="mt-1 block font-mono-tabular text-3xl font-black text-amber-600">
                  {top1 ? formatVnd(top1.totalAmountVnd) : '0 ₫'}
                </span>
              </div>

              {top1?.latestMessage && (
                <p className="mt-4 line-clamp-3 text-xs italic leading-relaxed text-[#525866]">
                  “{top1.latestMessage}”
                </p>
              )}
            </div>

            <div className="mt-6 flex items-center justify-between border-t border-amber-200/60 pt-4 text-xs text-amber-900/70">
              <span className="font-medium">
                {top1
                  ? `Số lượt ủng hộ: ${top1.donationsCount} lần`
                  : 'Xác thực tự động qua PayOS'}
              </span>
              <span className="font-mono-tabular font-semibold text-amber-700">
                {top1 ? top1.latestReceiptCode : 'TOP #01'}
              </span>
            </div>
          </article>

          {/* TOP 3: KHUNG ĐỒNG (BRONZE) */}
          <article
            data-testid="leaderboard-top-3"
            className={`relative flex flex-col justify-between rounded-3xl border-2 border-amber-700/40 bg-gradient-to-b from-orange-50/90 via-white to-white p-6 sm:p-7 shadow-lg shadow-orange-500/10 transition-transform duration-200 lg:order-3 ${
              isHighlightedDonor(top3?.donorName)
                ? 'ring-4 ring-[#6c63ff]/30'
                : ''
            }`}
          >
            <div>
              <div className="flex items-center justify-between gap-3">
                <div className="inline-flex items-center gap-2">
                  <span className="flex h-9 w-9 items-center justify-center rounded-full border border-amber-700/40 bg-gradient-to-br from-orange-100 to-amber-200 text-amber-900 shadow-xs">
                    <Award className="h-4 w-4 text-amber-800" />
                  </span>
                  <div>
                    <span className="block text-xs font-extrabold tracking-wider text-amber-800">
                      TOP 3 · HẠNG ĐỒNG
                    </span>
                    <span className="text-[11px] text-amber-900/70">
                      Quý quân ủng hộ CLB
                    </span>
                  </div>
                </div>

                <span className="font-mono-tabular text-2xl font-black text-amber-700/60">
                  #03
                </span>
              </div>

              <div className="mt-5 border-t border-orange-200/70 pt-5">
                {top3 ? (
                  <>
                    <div className="flex items-center gap-2">
                      <h3 className="text-xl font-extrabold text-[#181826]">
                        {top3.donorName}
                      </h3>
                      {isHighlightedDonor(top3.donorName) && (
                        <span className="text-xs font-bold text-[#5D50FE]">
                          · Mới cập nhật
                        </span>
                      )}
                    </div>
                    <p className="mt-1 text-xs font-medium text-[#525866]">
                      {top3.affiliation}
                    </p>
                  </>
                ) : (
                  <>
                    <h3 className="text-lg font-bold text-slate-400">
                      Đang chờ nhà hảo tâm Top 3
                    </h3>
                    <p className="mt-1 text-xs text-slate-400">
                      Vị trí Quý quân Hạng Đồng đang rộng mở
                    </p>
                  </>
                )}
              </div>

              <div className="mt-5 rounded-2xl border border-orange-200/80 bg-orange-50/60 px-4 py-3.5">
                <span className="block text-[11px] font-semibold text-amber-900/70">
                  Tổng số tiền đã ủng hộ
                </span>
                <span className="mt-0.5 block font-mono-tabular text-2xl font-extrabold text-amber-800">
                  {top3 ? formatVnd(top3.totalAmountVnd) : '0 ₫'}
                </span>
              </div>

              {top3?.latestMessage && (
                <p className="mt-4 line-clamp-2 text-xs italic leading-relaxed text-[#525866]">
                  “{top3.latestMessage}”
                </p>
              )}
            </div>

            <div className="mt-5 flex items-center justify-between border-t border-orange-100 pt-3.5 text-[11px] text-amber-900/60">
              <span>
                {top3
                  ? `Số lượt ủng hộ: ${top3.donationsCount} lần`
                  : 'Chưa có giao dịch'}
              </span>
              <span className="font-mono-tabular font-medium text-amber-800">
                {top3 ? top3.latestReceiptCode : '—'}
              </span>
            </div>
          </article>
        </div>

        {/* NÚT BẤM "HIỆN TẤT CẢ CÁC TOP" (CHO CÁC HẠNG DƯỚI TỪ TOP 4 TRỞ ĐI) */}
        <div className="mt-10 flex flex-col items-center">
          <button
            type="button"
            id="toggle-all-ranks-btn"
            onClick={() => setShowAllRanks((prev) => !prev)}
            className="inline-flex items-center gap-2.5 rounded-full border border-slate-200 bg-white px-7 py-3.5 text-sm font-bold text-[#5D50FE] shadow-sm transition-all hover:border-[#6c63ff] hover:bg-[#6c63ff]/5 cursor-pointer whitespace-nowrap"
          >
            <span>
              {showAllRanks
                ? 'Thu gọn danh sách các Top dưới'
                : allRanked.length > 3
                ? `Hiện tất cả các Top (Xem thêm ${allRanked.length - 3} nhà hảo tâm)`
                : 'Hiện tất cả các Top'}
            </span>
            {showAllRanks ? (
              <ChevronUp className="h-4 w-4 text-[#5D50FE]" />
            ) : (
              <ChevronDown className="h-4 w-4 text-[#5D50FE]" />
            )}
          </button>
        </div>

        {/* DANH SÁCH CÁC TOP DƯỚI (TOP 4 TRỞ ĐI - HIỆN KHI BẤM NÚT) */}
        {showAllRanks && (
          <div
            data-testid="lower-ranks-container"
            className="mt-8 overflow-hidden rounded-3xl border border-slate-200/90 bg-white shadow-sm"
          >
            <div className="flex flex-col justify-between gap-4 border-b border-slate-100 px-6 py-5 sm:flex-row sm:items-center">
              <div>
                <h3 className="text-base font-bold text-[#181826]">
                  Danh Sách Toàn Bộ Bảng Xếp Hạng (Từ Top #04)
                </h3>
                <p className="mt-0.5 text-xs text-[#525866]">
                  Tổng hợp các lượt ủng hộ đã thanh toán thành công theo thứ tự số tiền đóng góp
                </p>
              </div>

              {allRanked.length > 3 && (
                <div className="relative w-full sm:w-72">
                  <Search className="pointer-events-none absolute left-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400" />
                  <input
                    type="search"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    placeholder="Tìm tên người ủng hộ..."
                    aria-label="Tìm tên người ủng hộ trong bảng xếp hạng"
                    className="w-full rounded-full border border-slate-200 bg-[#F8F8FB] py-2 pl-10 pr-4 text-xs text-[#181826] placeholder-slate-400 focus:border-[#6c63ff] focus:bg-white focus:outline-none"
                  />
                </div>
              )}
            </div>

            {lowerRanks.length === 0 ? (
              <div className="px-6 py-10 text-center text-sm text-[#525866]">
                {allRanked.length <= 3
                  ? 'Hiện chưa có nhà hảo tâm ở các hạng từ #04 trở xuống.'
                  : 'Không tìm thấy nhà hảo tâm phù hợp với từ khóa tìm kiếm.'}
              </div>
            ) : (
              <div className="divide-y divide-slate-100">
                {lowerRanks.map((row) => {
                  const isJustUpdated = isHighlightedDonor(row.donorName);
                  return (
                    <div
                      key={`${row.rank}_${row.donorName}`}
                      className={`flex flex-col justify-between gap-3 px-6 py-4 transition-colors sm:flex-row sm:items-center ${
                        isJustUpdated
                          ? 'bg-[#6c63ff]/10'
                          : 'hover:bg-slate-50/80'
                      }`}
                    >
                      <div className="flex items-start gap-4 sm:items-center">
                        <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full border border-slate-200 bg-[#F8F8FB] font-mono-tabular text-xs font-extrabold text-[#5D50FE]">
                          #{String(row.rank).padStart(2, '0')}
                        </span>
                        <div>
                          <div className="flex flex-wrap items-center gap-2">
                            <span className="text-sm font-bold text-[#181826]">
                              {row.donorName}
                            </span>
                            {isJustUpdated && (
                              <span className="text-xs font-bold text-[#5D50FE]">
                                · Vừa thanh toán thành công
                              </span>
                            )}
                          </div>
                          <p className="mt-0.5 text-xs text-[#525866]">
                            {row.affiliation}
                          </p>
                          {row.latestMessage && (
                            <p className="mt-1 text-xs italic text-slate-500">
                              “{row.latestMessage}”
                            </p>
                          )}
                        </div>
                      </div>

                      <div className="flex items-center justify-between gap-4 pl-13 sm:justify-end sm:pl-0">
                        <span className="font-mono-tabular text-xs text-slate-400">
                          {row.latestReceiptCode}
                        </span>
                        <span className="font-mono-tabular text-base font-extrabold text-[#5D50FE]">
                          {formatVnd(row.totalAmountVnd)}
                        </span>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        )}
          </>
        )}
      </section>

      {/* LỜI NHẮN GỬI TỪ NGƯỜI ỦNG HỘ THỰC TẾ (ĐÃ XÓA CÁC LỜI NHẮN ẢO) */}
      <section
        id="donor-messages-section"
        className="scroll-mt-24 border-t border-slate-200/80 py-14 sm:py-16"
      >
        <div className="flex flex-col justify-between gap-4 sm:flex-row sm:items-end">
          <div>
            <div className="inline-flex items-center gap-2 text-xs font-semibold text-[#5D50FE]">
              <MessageSquareHeart className="h-4 w-4" />
              <span>Lời Nhắn Gửi Thực Tế</span>
            </div>
            <h2 className="mt-1.5 text-2xl font-extrabold tracking-tight text-[#181826] sm:text-3xl">
              Lời Chúc Từ Cộng Đồng Ủng Hộ BWAN
            </h2>
          </div>

          <button
            type="button"
            onClick={onScrollToDonate}
            className="inline-flex items-center gap-2 rounded-full bg-[#5D50FE] px-5 py-2.5 text-xs font-bold text-white shadow-sm shadow-[#5D50FE]/20 transition-colors hover:bg-[#4B3FE8] cursor-pointer whitespace-nowrap self-start sm:self-auto"
          >
            <span>Gửi lời nhắn & Ủng hộ ngay</span>
          </button>
        </div>

        {donorMessages.length === 0 ? (
          <div className="mt-8 rounded-3xl border border-dashed border-slate-300 bg-white/80 p-10 text-center">
            <MessageSquareHeart className="mx-auto h-8 w-8 text-[#5D50FE]/60" />
            <p className="mt-3 text-base font-bold text-[#181826]">
              Chưa có lời nhắn quyên góp nào
            </p>
            <p className="mx-auto mt-1 max-w-md text-xs leading-relaxed text-[#525866]">
              Các lời chúc thực tế của người ủng hộ sẽ tự động xuất hiện tại đây ngay sau khi hoàn tất quét mã QR thanh toán.
            </p>
          </div>
        ) : (
          <div className="mt-8 grid grid-cols-1 gap-5 md:grid-cols-2 lg:grid-cols-3">
            {donorMessages.map((record) => {
              const dateStr = record.timestampIso
                .slice(0, 10)
                .split('-')
                .reverse()
                .join('/');
              return (
                <article
                  key={record.id}
                  className="flex flex-col justify-between rounded-2xl border border-slate-200/80 bg-white p-6 shadow-xs"
                >
                  <div>
                    <div className="flex items-center justify-between text-xs text-slate-400">
                      <span className="font-mono-tabular font-semibold text-[#5D50FE]">
                        {record.verifiedReceiptCode}
                      </span>
                      <span className="font-mono-tabular">{dateStr}</span>
                    </div>
                    <blockquote className="mt-3 text-sm leading-relaxed text-[#334155]">
                      “{record.message}”
                    </blockquote>
                  </div>

                  <div className="mt-5 flex items-center justify-between border-t border-slate-100 pt-4">
                    <div>
                      <p className="text-sm font-bold text-[#181826]">
                        {record.isAnonymous ? 'Nhà Hảo Tâm Ẩn Danh' : record.name}
                      </p>
                      <p className="text-xs text-[#525866]">
                        {record.affiliation}
                      </p>
                    </div>
                    <span className="font-mono-tabular text-sm font-extrabold text-[#5D50FE]">
                      {formatVnd(record.amountVnd)}
                    </span>
                  </div>
                </article>
              );
            })}
          </div>
        )}
      </section>
    </>
  );
};
