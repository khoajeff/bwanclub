import React, { useState, useEffect } from 'react';
import { Navbar, AppLanguage } from './components/Navbar';
import { HeroSection } from './components/HeroSection';
import { ClubDivisionsSection } from './components/ClubDivisionsSection';
import { CategorySyncHubSection } from './components/CategorySyncHubSection';
import { ChemClubDonationModule } from './modules/chem-donation';
import { AIAdvisorSection } from './components/AIAdvisorSection';
import { JoinClubModal, MemberRegistration } from './components/JoinClubModal';
import { BwanHexLogo } from './components/BwanHexLogo';
import {
  INITIAL_CLUB_PROJECTS,
  INITIAL_CLUB_EVENTS,
  ClubProjectItem,
} from './utils/chemistryEngine';
import { X, ArrowRight } from 'lucide-react';

const INITIAL_MEMBERS: MemberRegistration[] = [
  {
    id: 'mem-1',
    fullName: 'Trần Hoàng Bảo Ngọc',
    email: 'baongoc@bwanclub.edu.vn',
    gradeClass: 'Lớp 12 Chuyên Hóa',
    division: 'Ban Chuyên Môn & Phòng Lab',
    favoriteElement: 'Pt · 78 (Xúc tác Bạch kim)',
    registeredAt: 'Gen 6 · 2026',
  },
  {
    id: 'mem-2',
    fullName: 'Lê Nguyễn Minh Quân',
    email: 'minhquan@bwanclub.edu.vn',
    gradeClass: 'Lớp 11A1 Hóa',
    division: 'Ban Truyền Thông & Thiết Kế',
    favoriteElement: 'Ne · 10 (Ánh sáng Neon)',
    registeredAt: 'Gen 6 · 2026',
  },
  {
    id: 'mem-3',
    fullName: 'Vũ Hà Phương Anh',
    email: 'phuonganh@bwanclub.edu.vn',
    gradeClass: 'Lớp 11 Chuyên Hóa',
    division: 'Ban Sự Kiện & Đối Ngoại',
    favoriteElement: 'Au · 79 (Tinh thể Vàng)',
    registeredAt: 'Gen 6 · 2026',
  },
];

export default function App() {
  const [showTopBanner, setShowTopBanner] = useState(true);
  const [isDark, setIsDark] = useState(false);
  const [lang, setLang] = useState<AppLanguage>('vi');
  const [projects, setProjects] = useState<ClubProjectItem[]>(
    INITIAL_CLUB_PROJECTS
  );
  const [events] = useState(INITIAL_CLUB_EVENTS);
  const [members, setMembers] = useState<MemberRegistration[]>(INITIAL_MEMBERS);
  const [joinModalOpen, setJoinModalOpen] = useState(false);
  const [selectedDivision, setSelectedDivision] = useState(
    'Ban Chuyên Môn & Phòng Lab'
  );

  useEffect(() => {
    const root = document.documentElement;
    if (isDark) {
      root.classList.add('dark');
    } else {
      root.classList.remove('dark');
    }
  }, [isDark]);

  const handleOpenJoinModal = (dept = 'Ban Chuyên Môn & Phòng Lab') => {
    setSelectedDivision(dept);
    setJoinModalOpen(true);
  };

  const handleAddProject = (newProj: ClubProjectItem) => {
    setProjects((prev) => [newProj, ...prev]);
  };

  const handleRegisterMember = (newMember: MemberRegistration) => {
    setMembers((prev) => [newMember, ...prev]);
  };

  return (
    <div className="min-h-screen flex flex-col bg-white dark:bg-[#0D0C1D] text-[#1F1F2E] dark:text-[#F8FAFC] transition-colors">
      {/* Google One Signature Top Announcement Bar in #6C63FF */}
      {showTopBanner && (
        <div className="bg-[#6C63FF] text-white text-xs sm:text-sm py-2.5 px-4 sm:px-6">
          <div className="max-w-7xl mx-auto flex items-center justify-between gap-4">
            <p className="text-center flex-1 leading-snug">
              {lang === 'vi' ? (
                <>
                  Chào mừng mùa tuyển thành viên{' '}
                  <strong>BWAN Gen 6 — Chemistry Lab</strong>: Trải nghiệm dự án
                  Giải mã 18 Nguyên tố Nhân cách & Quỹ Học Thuật CLB.{' '}
                </>
              ) : (
                <>
                  Welcome to <strong>BWAN Gen 6 — Chemistry Lab</strong>{' '}
                  recruitment season: Explore the 18-Element Personality Test &
                  Club Endowment Fund.{' '}
                </>
              )}
              <a
                href="#quyen-gop"
                className="underline font-semibold hover:text-[#E5E3FF] cursor-pointer whitespace-nowrap"
              >
                {lang === 'vi' ? 'Ủng hộ & Xem Top Donate' : 'Donate & View Leaderboard'}
              </a>
            </p>
            <button
              type="button"
              aria-label="Đóng thông báo CLB"
              onClick={() => setShowTopBanner(false)}
              className="p-1 rounded-full hover:bg-white/15 transition-colors shrink-0 cursor-pointer"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>
      )}

      {/* Top Navigation Bar with Transparent Club Logo + Theme & Language Controls */}
      <Navbar
        onOpenJoinModal={handleOpenJoinModal}
        isDark={isDark}
        onToggleTheme={() => setIsDark((prev) => !prev)}
        lang={lang}
        onToggleLang={() => setLang((prev) => (prev === 'vi' ? 'en' : 'vi'))}
      />

      {/* Main Content */}
      <main className="flex-1">
        {/* Google One Warm Gradient Hero with Transparent Hexagonal Logo */}
        <HeroSection
          onOpenJoinModal={handleOpenJoinModal}
          totalProjectsCount={projects.length}
          totalEventsCount={events.length}
          lang={lang}
        />

        {/* Google One 3-Column Tonal Cards for Club Departments */}
        <ClubDivisionsSection
          onSelectDivision={handleOpenJoinModal}
          lang={lang}
        />

        {/* Club Projects Showcase, Flagship 18-Elements App, Upcoming Events & Category Sync Hub */}
        <CategorySyncHubSection
          projects={projects}
          events={events}
          onAddProject={handleAddProject}
          onOpenJoinModal={handleOpenJoinModal}
          lang={lang}
        />

        {/* Integrated PayOS QR Donation & Real-Time Top Donate Leaderboard Module */}
        <ChemClubDonationModule embeddedMode />

        {/* Bottom Gemini-Inspired Soft Minimal Gradient Wrapper (Chatbot + Closing Banner + Footer) */}
        <div className="gemini-bottom-glow">
          {/* Multi-Turn Gemini Club Chatbot */}
          <AIAdvisorSection lang={lang} />

          {/* Closing Club Invitation Banner inside the Gemini Gradient Glow */}
          <section className="py-16 px-4 sm:px-6 lg:px-8 text-center">
            <div className="max-w-3xl mx-auto">
              <div className="inline-flex items-center justify-center mb-4">
                <BwanHexLogo className="w-12 h-12" />
              </div>
              <h2 className="font-display text-3xl sm:text-4xl font-extrabold text-[#1F1F2E] dark:text-white tracking-tight text-balance">
                {lang === 'vi' ? (
                  <>
                    Sẵn sàng khởi tạo{' '}
                    <span className="google-one-chem-gradient-text">
                      phản ứng của riêng bạn
                    </span>{' '}
                    cùng BWAN?
                  </>
                ) : (
                  <>
                    Ready to spark{' '}
                    <span className="google-one-chem-gradient-text">
                      your own reaction
                    </span>{' '}
                    with BWAN?
                  </>
                )}
              </h2>
              <p className="mt-3 text-sm sm:text-base text-[#4A4A68] dark:text-[#CBD5E1] max-w-xl mx-auto">
                {lang === 'vi'
                  ? 'Gia nhập cộng đồng yêu Hóa Học BWAN Gen 6 để cùng thực hiện các dự án thực nghiệm, đêm hội Hóa phát quang và lan tỏa tri thức khoa học.'
                  : 'Join BWAN Gen 6 Chemistry Club to build experimental projects, host chemiluminescence nights, and share scientific passion.'}
              </p>
              <div className="mt-7">
                <button
                  type="button"
                  onClick={() =>
                    handleOpenJoinModal('Ban Chuyên Môn & Phòng Lab')
                  }
                  className="inline-flex items-center gap-2.5 px-7 py-3.5 rounded-full google-one-chem-btn font-semibold text-sm sm:text-base active:scale-95 cursor-pointer whitespace-nowrap shrink-0"
                >
                  <span>
                    {lang === 'vi'
                      ? 'Đăng ký thành viên BWAN Gen 6'
                      : 'Apply for BWAN Gen 6'}
                  </span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              </div>
            </div>
          </section>

          {/* Quiet Google One Styled Footer blending into the Gemini bottom gradient */}
          <footer className="py-10 px-4 sm:px-6 lg:px-8 border-t border-[#6C63FF]/15 dark:border-[#6C63FF]/25">
            <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-start sm:items-center justify-between gap-6 text-xs text-[#5F6368] dark:text-[#94A3B8]">
              <div className="flex items-center gap-3">
                <BwanHexLogo className="w-7 h-7" />
                <div>
                  <span className="font-display text-sm font-bold text-[#1F1F2E] dark:text-white">
                    <span className="text-[#6C63FF]">BWAN</span> Club
                  </span>
                  <span className="mx-2 text-[#6C63FF]">·</span>
                  <span>Google One Chemistry Design Edition</span>
                </div>
              </div>

              <div className="flex flex-wrap items-center gap-6">
                <a
                  href="#gioi-thieu"
                  className="hover:text-[#6C63FF] dark:hover:text-[#A39DFF] transition-colors"
                >
                  {lang === 'vi' ? 'Tổng quan' : 'Overview'}
                </a>
                <a
                  href="#ve-clb"
                  className="hover:text-[#6C63FF] dark:hover:text-[#A39DFF] transition-colors"
                >
                  {lang === 'vi' ? 'Phân ban' : 'Divisions'}
                </a>
                <a
                  href="#du-an"
                  className="hover:text-[#6C63FF] dark:hover:text-[#A39DFF] transition-colors"
                >
                  {lang === 'vi' ? 'Dự án' : 'Projects'}
                </a>
                <a
                  href="#su-kien"
                  className="hover:text-[#6C63FF] dark:hover:text-[#A39DFF] transition-colors"
                >
                  {lang === 'vi' ? 'Sự kiện' : 'Events'}
                </a>
                <a
                  href="#quyen-gop"
                  className="hover:text-[#6C63FF] dark:hover:text-[#A39DFF] transition-colors"
                >
                  {lang === 'vi' ? 'Quyên góp' : 'Donate'}
                </a>
                <a
                  href="#leaderboard-section"
                  className="hover:text-[#6C63FF] dark:hover:text-[#A39DFF] transition-colors"
                >
                  {lang === 'vi' ? 'Bảng xếp hạng' : 'Leaderboard'}
                </a>
              </div>
            </div>
          </footer>
        </div>
      </main>

      {/* Member Application Modal */}
      <JoinClubModal
        isOpen={joinModalOpen}
        defaultDivision={selectedDivision}
        onClose={() => setJoinModalOpen(false)}
        onRegisterMember={handleRegisterMember}
        registeredMembers={members}
      />
    </div>
  );
}
