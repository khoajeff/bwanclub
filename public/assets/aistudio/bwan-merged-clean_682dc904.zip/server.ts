import express from 'express';
import { createServer as createViteServer } from 'vite';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import dotenv from 'dotenv';
import { GoogleGenAI } from '@google/genai';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const DATA_FILE = path.join(__dirname, 'verified-donations.json');

const app = express();
const PORT = Number(process.env.PORT) || 3000;

app.use(express.json({ limit: '5mb' }));

interface ChatHistoryEntry {
  role: 'user' | 'model';
  text: string;
}

interface StoredDonation {
  id: string;
  paymentLinkId: string;
  orderCode?: string | number;
  name: string;
  affiliation: string;
  amountVnd: number;
  message: string;
  timestampIso: string;
  verifiedReceiptCode: string;
}

function readVerifiedDonations(): StoredDonation[] {
  try {
    if (!fs.existsSync(DATA_FILE)) return [];
    const raw = fs.readFileSync(DATA_FILE, 'utf-8');
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) ? parsed : [];
  } catch {
    return [];
  }
}

function writeVerifiedDonations(list: StoredDonation[]): void {
  try {
    fs.writeFileSync(DATA_FILE, JSON.stringify(list, null, 2), 'utf-8');
  } catch {
    // Ignore write errors in read-only environments
  }
}

function sanitizeDonorName(raw: string): string {
  return (
    String(raw || '')
      .replace(/^.*?\bBWAN\s*/i, '')
      .trim() || 'Nhà Hảo Tâm Ẩn Danh'
  );
}

function getFallbackClubChatReply(message: string, mode: string): string {
  const lower = message.toLowerCase();

  if (lower.includes('dự án') || lower.includes('18 nguyên tố') || lower.includes('gen 6')) {
    return `Tại **BWAN Chemistry Lab (Gen 6)**, dự án tiêu biểu nhất hiện nay là **Hệ Thống Giải Mã 18 Nguyên Tố Nhân Cách** — giúp mỗi thành viên khám phá nguyên tố đại diện qua 5 chiều sâu: *Tính cách, Tư duy, Làm việc nhóm, Xử lý áp lực và Phong cách sáng tạo*.\n\nNgoài ra, CLB còn triển khai **Dự án Hóa Học Xanh (Chỉ thị pH Anthocyanin tự nhiên)** và **Triển lãm Nuôi Đơn Tinh Thể Silicat & Đồng Sunfat**.`;
  }

  if (lower.includes('donate') || lower.includes('quyên góp') || lower.includes('ủng hộ')) {
    return `Bạn có thể ủng hộ trực tiếp cho **Quỹ Học Thuật & Thực Nghiệm BWAN** ngay tại mục **Quyên góp** trên trang web (tối thiểu từ 2.000 VNĐ). Hệ thống tích hợp cổng **PayOS** tự động tạo mã QR và vinh danh tên bạn lên **Bảng Xếp Hạng Top Donate** theo thời gian thực ngay sau khi quét mã thành công!`;
  }

  if (lower.includes('sự kiện') || lower.includes('tuyển') || lower.includes('tham gia') || lower.includes('đăng ký')) {
    return `Chuỗi sự kiện sắp tới của CLB Hóa Học bao gồm:\n1. **15/11/2026**: Ngày Hội Tuyển Thành Viên & Giải Mã Nguyên Tố BWAN Gen 6 (Phòng Lab Hóa Trung Tâm).\n2. **28/11/2026**: Workshop Nghệ Thuật Nuôi Tinh Thể Đồng Sunfat ($CuSO_4\\cdot 5H_2O$).\n3. **12/12/2026**: Seminar Học Thuật Giải Mã Cơ Chế Phản Ứng & Động Hóa Học.\n\nBạn có thể nhấn nút **"Đăng ký"** ngay trên thanh điều hướng để ghi danh vào 1 trong 3 ban chuyên môn của CLB!`;
  }

  if (lower.includes('giới thiệu') || lower.includes('ban') || lower.includes('clb')) {
    return `**BWAN Chemistry Club** là câu lạc bộ học thuật & thực nghiệm Hóa Học hiện đại, hoạt động với 3 phân ban cốt lõi:\n• **Ban Chuyên Môn & Phòng Lab (Pt · 78)**: Thiết kế thí nghiệm Hóa phát quang, nuôi tinh thể và kiểm định an toàn.\n• **Ban Truyền Thông & Sáng Tạo (Ne · 10)**: Thiết kế giao diện dự án số và Infographic Hóa học.\n• **Ban Sự Kiện & Đối Ngoại (Au · 79)**: Điều phối các đêm hội khoa học và kết nối cộng đồng yêu Hóa học.`;
  }

  return `Chào bạn từ **BWAN Chemistry Lab (${mode})**! Mình là Trợ lý Cố vấn của Câu lạc bộ Hóa Học.\n\nVề câu hỏi *"${message}"*: CLB hiện đang mở cổng giới thiệu **Chuỗi Dự Án Gen 6**, **Lịch Sự Kiện Thực Nghiệm** và **Quỹ Học Thuật & Bảng Xếp Hạng Top Donate** với tông màu chủ đạo #6c63ff. Bạn muốn tìm hiểu chi tiết hơn về dự án, sự kiện sắp tới hay giải đáp kiến thức Hóa Học chuyên sâu?`;
}

app.post('/api/club/chat', async (req, res) => {
  const { message, history = [], mode = 'general' } = req.body || {};

  if (!message || typeof message !== 'string' || !message.trim()) {
    return res.status(400).json({ error: 'Vui lòng nhập nội dung tin nhắn để trò chuyện cùng CLB.' });
  }

  const selectedModel =
    mode === 'fast'
      ? 'gemini-3.1-flash-lite'
      : mode === 'deep'
      ? 'gemini-4-argon'
      : 'gemini-3.8-flash';

  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey || apiKey === 'MY_GEMINI_API_KEY') {
    return res.json({
      model: selectedModel,
      reply: getFallbackClubChatReply(message.trim(), selectedModel),
    });
  }

  try {
    const ai = new GoogleGenAI({
      apiKey,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        },
      },
    });

    const formattedHistory = Array.isArray(history)
      ? (history as ChatHistoryEntry[])
          .filter((h) => h && (h.role === 'user' || h.role === 'model') && typeof h.text === 'string')
          .map((h) => ({
            role: h.role,
            parts: [{ text: h.text }],
          }))
      : [];

    const chat = ai.chats.create({
      model: selectedModel,
      history: formattedHistory,
      config: {
        systemInstruction:
          'Bạn là Trợ lý Đại sứ chính thức của Câu lạc bộ Hóa Học BWAN (BWAN Chemistry Lab — Gen 6). Nhiệm vụ của bạn là giới thiệu nhiệt tình, súc tích về tầm nhìn của CLB, 3 phân ban (Ban Chuyên Môn Pt-78, Ban Truyền Thông Ne-10, Ban Sự Kiện Au-79), các dự án nổi bật (Giải mã 18 Nguyên tố Nhân cách, Hóa phát quang Luminol, Hóa học xanh Anthocyanin, Vườn tinh thể Silicat), Quỹ quyên góp Top Donate, lịch sự kiện sắp tới và giải đáp các câu hỏi Hóa học thú vị bằng tiếng Việt rõ ràng.',
      },
    });

    const response = await chat.sendMessage({
      message: message.trim(),
    });

    return res.json({
      model: selectedModel,
      reply: response.text || getFallbackClubChatReply(message.trim(), selectedModel),
    });
  } catch {
    return res.json({
      model: selectedModel,
      reply: getFallbackClubChatReply(message.trim(), selectedModel),
    });
  }
});

// 1. Lấy danh sách các khoản donate ĐÃ THANH TOÁN THÀNH CÔNG (PAID)
app.get('/api/donations', (_req, res) => {
  const donations = readVerifiedDonations();
  res.json({ donations });
});

// 2. Kiểm tra trạng thái thanh toán thực tế từ cổng PayOS (PENDING / PAID / CANCELLED)
app.post('/api/payos-status/:paymentLinkId', async (req, res) => {
  const { paymentLinkId } = req.params;
  const cleanId = (paymentLinkId || '').replace(/[^a-zA-Z0-9_-]/g, '');

  if (!cleanId) {
    res.status(400).json({ error: 'Invalid paymentLinkId' });
    return;
  }

  try {
    const payosRes = await fetch(
      `https://pay.payos.vn/api/web/${cleanId}/check-status/`,
      {
        method: 'POST',
        headers: {
          Accept: 'application/json',
          'Content-Type': 'application/json',
        },
      }
    );

    if (!payosRes.ok) {
      res.status(payosRes.status).json({
        status: 'PENDING',
        error: `PayOS returned ${payosRes.status}`,
      });
      return;
    }

    const json = (await payosRes.json()) as {
      code?: string;
      data?: {
        status?: string;
        amountRemaining?: number;
      };
    };

    const paymentStatus = json?.data?.status || 'PENDING';
    const amountRemaining = json?.data?.amountRemaining;

    if (paymentStatus === 'PAID') {
      const existing = readVerifiedDonations();
      let record = existing.find((d) => d.paymentLinkId === cleanId);

      if (!record && req.body && req.body.amountVnd && req.body.donorName) {
        record = {
          id: `don_${cleanId}`,
          paymentLinkId: cleanId,
          orderCode: req.body.orderCode,
          name: sanitizeDonorName(req.body.donorName),
          affiliation:
            String(req.body.affiliation || '').trim() ||
            'Thành viên & Người yêu Hóa học BWAN',
          amountVnd: Number(req.body.amountVnd) || 0,
          message: String(req.body.message || '').trim(),
          timestampIso: new Date().toISOString(),
          verifiedReceiptCode:
            String(req.body.receiptCode || '').trim() ||
            `ORD-${req.body.orderCode || cleanId.slice(0, 6).toUpperCase()}`,
        };
        const updated = [record, ...existing];
        writeVerifiedDonations(updated);
        res.json({
          status: 'PAID',
          amountRemaining: 0,
          verifiedRecord: record,
          donations: updated,
        });
        return;
      }

      res.json({
        status: 'PAID',
        amountRemaining: 0,
        verifiedRecord: record || null,
        donations: existing,
      });
      return;
    }

    res.json({
      status: paymentStatus,
      amountRemaining,
    });
  } catch (err) {
    res.status(500).json({
      status: 'PENDING',
      error: err instanceof Error ? err.message : 'Check status error',
    });
  }
});

async function startServer() {
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (_req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`BWAN Chemistry Club Server running on http://localhost:${PORT}`);
  });
}

startServer();
