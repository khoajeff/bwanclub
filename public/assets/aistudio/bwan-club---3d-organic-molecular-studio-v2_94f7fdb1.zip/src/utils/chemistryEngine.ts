export interface Atom3D {
  el: string | number;
  x: number;
  y: number;
  z: number;
}

export type BondTuple = [number, number, number?];

export interface MoleculeData {
  id: string;
  formula?: string;
  mw?: number;
  atoms: Atom3D[];
  bonds: BondTuple[];
}

export interface ElementMeta {
  sym: string;
  covR: number;
  vdwR: number;
  mass: number;
}

export const ELEMENT_TABLE: Record<string, ElementMeta> = {
  H:  { sym: "H",  covR: 0.32, vdwR: 1.10, mass: 1.008 },
  B:  { sym: "B",  covR: 0.84, vdwR: 1.92, mass: 10.81 },
  C:  { sym: "C",  covR: 0.76, vdwR: 1.70, mass: 12.011 },
  N:  { sym: "N",  covR: 0.71, vdwR: 1.55, mass: 14.007 },
  O:  { sym: "O",  covR: 0.66, vdwR: 1.52, mass: 15.999 },
  F:  { sym: "F",  covR: 0.57, vdwR: 1.47, mass: 18.998 },
  Na: { sym: "Na", covR: 1.66, vdwR: 2.27, mass: 22.99 },
  Mg: { sym: "Mg", covR: 1.41, vdwR: 1.73, mass: 24.305 },
  Si: { sym: "Si", covR: 1.11, vdwR: 2.10, mass: 28.085 },
  P:  { sym: "P",  covR: 1.07, vdwR: 1.80, mass: 30.974 },
  S:  { sym: "S",  covR: 1.05, vdwR: 1.80, mass: 32.06 },
  Cl: { sym: "Cl", covR: 1.02, vdwR: 1.75, mass: 35.45 },
  K:  { sym: "K",  covR: 2.03, vdwR: 2.75, mass: 39.098 },
  Ca: { sym: "Ca", covR: 1.76, vdwR: 2.31, mass: 40.078 },
  Mn: { sym: "Mn", covR: 1.39, vdwR: 2.00, mass: 54.938 },
  Fe: { sym: "Fe", covR: 1.32, vdwR: 2.00, mass: 55.845 },
  Co: { sym: "Co", covR: 1.26, vdwR: 2.00, mass: 58.933 },
  Ni: { sym: "Ni", covR: 1.24, vdwR: 1.63, mass: 58.693 },
  Cu: { sym: "Cu", covR: 1.32, vdwR: 1.40, mass: 63.546 },
  Zn: { sym: "Zn", covR: 1.22, vdwR: 1.39, mass: 65.38 },
  Br: { sym: "Br", covR: 1.20, vdwR: 1.85, mass: 79.904 },
  I:  { sym: "I",  covR: 1.39, vdwR: 1.98, mass: 126.90 },
};

export function normalizeSymbol(el: string | number): string {
  const s = String(el).trim();
  if (!s) return "C";
  const formatted = s.charAt(0).toUpperCase() + s.slice(1).toLowerCase();
  return ELEMENT_TABLE[formatted] ? formatted : "C";
}

export function distance3D(a: { x: number; y: number; z: number }, b: { x: number; y: number; z: number }): number {
  const dx = a.x - b.x;
  const dy = a.y - b.y;
  const dz = a.z - b.z;
  return Math.sqrt(dx * dx + dy * dy + dz * dz);
}

export function computeAngleDegrees(
  a: { x: number; y: number; z: number },
  b: { x: number; y: number; z: number },
  c: { x: number; y: number; z: number }
): number {
  const v1 = { x: a.x - b.x, y: a.y - b.y, z: a.z - b.z };
  const v2 = { x: c.x - b.x, y: c.y - b.y, z: c.z - b.z };
  const m1 = Math.sqrt(v1.x * v1.x + v1.y * v1.y + v1.z * v1.z);
  const m2 = Math.sqrt(v2.x * v2.x + v2.y * v2.y + v2.z * v2.z);
  if (m1 < 1e-5 || m2 < 1e-5) return 0;
  const dot = (v1.x * v2.x + v1.y * v2.y + v1.z * v2.z) / (m1 * m2);
  const clamped = Math.max(-1, Math.min(1, dot));
  return (Math.acos(clamped) * 180) / Math.PI;
}

export function computeFormulaFromAtoms(atoms: Atom3D[]): string {
  const counts: Record<string, number> = {};
  atoms.forEach((a) => {
    const s = normalizeSymbol(a.el);
    counts[s] = (counts[s] || 0) + 1;
  });
  const keys = Object.keys(counts).sort((a, b) => {
    if (a === "C") return -1;
    if (b === "C") return 1;
    if (a === "H") return -1;
    if (b === "H") return 1;
    return a.localeCompare(b);
  });
  return keys.map((k) => (counts[k] > 1 ? `${k}${counts[k]}` : k)).join("");
}

export function computeMolarMassFromAtoms(atoms: Atom3D[]): number {
  return atoms.reduce((sum, a) => {
    const sym = normalizeSymbol(a.el);
    return sum + (ELEMENT_TABLE[sym]?.mass || 12.011);
  }, 0);
}

export function analyzeHybridizations(mol: MoleculeData): string[] {
  const n = mol.atoms.length;
  const adj: Array<Array<{ to: number; order: number }>> = Array.from({ length: n }, () => []);
  const maxBondOrder = new Float32Array(n);
  const hasAromatic = new Uint8Array(n);

  (mol.bonds || []).forEach(([i, j, order = 1]) => {
    if (i >= 0 && i < n && j >= 0 && j < n && i !== j) {
      adj[i].push({ to: j, order });
      adj[j].push({ to: i, order });
      if (order > maxBondOrder[i]) maxBondOrder[i] = order;
      if (order > maxBondOrder[j]) maxBondOrder[j] = order;
      if (order === 1.5) {
        hasAromatic[i] = 1;
        hasAromatic[j] = 1;
      }
    }
  });

  return mol.atoms.map((atom, idx) => {
    const el = normalizeSymbol(atom.el);
    if (el === "H" || el === "F" || el === "Cl" || el === "Br" || el === "I") {
      return "s";
    }
    const deg = adj[idx].length;
    const maxBo = maxBondOrder[idx];
    const arom = hasAromatic[idx] === 1;

    if (el === "C") {
      if (arom || maxBo === 2 || deg === 3) return "sp²";
      if (maxBo === 3 || deg === 2) return "sp";
      return "sp³";
    }
    if (el === "N") {
      if (arom || maxBo === 2) return "sp²";
      if (maxBo === 3 || deg === 1) return "sp";
      const conj = adj[idx].some((nb) => hasAromatic[nb.to] || maxBondOrder[nb.to] >= 2);
      return conj ? "sp²" : "sp³";
    }
    if (el === "O" || el === "S") {
      if (maxBo === 2 || arom) return "sp²";
      const conj = adj[idx].some((nb) => hasAromatic[nb.to] || maxBondOrder[nb.to] >= 2);
      return conj ? "sp²" : "sp³";
    }
    return deg <= 2 ? "sp" : deg === 3 ? "sp²" : "sp³";
  });
}

export class CloudMoleculeCache {
  private memory = new Map<string, MoleculeData>();
  private maxEntries: number;

  constructor(maxEntries = 40) {
    this.maxEntries = maxEntries;
  }

  public makeKey(source: string, query: string): string {
    return `${source.trim().toLowerCase()}::${query.trim().toLowerCase()}`;
  }

  public get(source: string, query: string): MoleculeData | null {
    const key = this.makeKey(source, query);
    const hit = this.memory.get(key);
    if (!hit) return null;
    // Refresh LRU order
    this.memory.delete(key);
    this.memory.set(key, hit);
    return hit;
  }

  public set(source: string, query: string, mol: MoleculeData): void {
    const key = this.makeKey(source, query);
    if (this.memory.has(key)) {
      this.memory.delete(key);
    } else if (this.memory.size >= this.maxEntries) {
      const oldestKey = this.memory.keys().next().value;
      if (oldestKey !== undefined) {
        this.memory.delete(oldestKey);
      }
    }
    this.memory.set(key, mol);
  }
}
