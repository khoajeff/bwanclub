import { describe, it } from "node:test";
import assert from "node:assert/strict";
import {
  distance3D,
  computeAngleDegrees,
  computeFormulaFromAtoms,
  computeMolarMassFromAtoms,
  analyzeHybridizations,
  CloudMoleculeCache,
} from "./chemistryEngine.ts";

describe("BWAN CLUB v2 Chemistry & Cache Engine", () => {
  it("computes Hill system molecular formula and molar mass accurately", () => {
    const ethanolAtoms = [
      { el: "C", x: -1.18, y: -0.25, z: 0 },
      { el: "C", x: 0.12, y: 0.54, z: 0 },
      { el: "O", x: 1.21, y: -0.37, z: 0 },
      { el: "H", x: 2.02, y: 0.15, z: 0 },
      { el: "H", x: -2.02, y: 0.45, z: 0 },
      { el: "H", x: -1.24, y: -0.88, z: 0.89 },
      { el: "H", x: -1.24, y: -0.88, z: -0.89 },
      { el: "H", x: 0.18, y: 1.18, z: 0.89 },
      { el: "H", x: 0.18, y: 1.18, z: -0.89 },
    ];
    assert.equal(computeFormulaFromAtoms(ethanolAtoms), "C2H6O");
    const mw = computeMolarMassFromAtoms(ethanolAtoms);
    assert.ok(Math.abs(mw - 46.069) < 0.05);
  });

  it("computes tetrahedral bond angles (~109.47 deg) and 3D distances", () => {
    const c = { x: 0, y: 0, z: 0 };
    const h1 = { x: 0.629, y: 0.629, z: 0.629 };
    const h2 = { x: -0.629, y: -0.629, z: 0.629 };
    const d = distance3D(c, h1);
    assert.ok(Math.abs(d - 1.089) < 0.01);
    const angle = computeAngleDegrees(h1, c, h2);
    assert.ok(Math.abs(angle - 109.47) < 0.1);
  });

  it("deduces sp3, sp2, and sp hybridizations accurately", () => {
    // Acetylene HC#CH (sp)
    const acetylene = {
      id: "acetylene",
      atoms: [
        { el: "C", x: -0.602, y: 0, z: 0 },
        { el: "C", x: 0.602, y: 0, z: 0 },
        { el: "H", x: -1.663, y: 0, z: 0 },
        { el: "H", x: 1.663, y: 0, z: 0 },
      ],
      bonds: [
        [0, 1, 3],
        [0, 2, 1],
        [1, 3, 1],
      ] as [number, number, number][],
    };
    assert.deepEqual(analyzeHybridizations(acetylene), ["sp", "sp", "s", "s"]);
  });

  it("caches and evicts molecules in LRU order in CloudMoleculeCache", () => {
    const cache = new CloudMoleculeCache(2);
    const molA = { id: "a", atoms: [], bonds: [] };
    const molB = { id: "b", atoms: [], bonds: [] };
    const molC = { id: "c", atoms: [], bonds: [] };

    cache.set("pubchem", "Aspirin", molA);
    cache.set("pubchem", "Caffeine", molB);
    // Access Aspirin so it becomes most recently used
    assert.equal(cache.get("pubchem", "aspirin")?.id, "a");
    // Adding C should evict Caffeine (b), keeping Aspirin (a)
    cache.set("pubchem", "Glucose", molC);
    assert.equal(cache.get("pubchem", "Caffeine"), null);
    assert.equal(cache.get("pubchem", "Aspirin")?.id, "a");
    assert.equal(cache.get("pubchem", "Glucose")?.id, "c");
  });
});
